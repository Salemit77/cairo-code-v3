// 3. SYSTEM 1: BUILDING GENERATOR (Authentic Cairo Code Architectural Composition)
      // -------------------------------------------------------------------
      class BuildingGenerator {
        static generate(state, width, height) {
          const rng = new SeededRNG(state.seed ^ (state.salts.buildings * 7919));
          const count = state.sysconfig.buildingCount;
          const densityFactor = state.sysconfig.buildingDensity / 100;
          const heightScale = state.sysconfig.buildingHeight / 65;
          const heightVar = state.sysconfig.heightVariation / 100;
          const archRand = state.sysconfig.archRandomness / 100;
          const constructionProb = Math.min(0.92, (state.cranes.constructionDensity / 100) * 0.75);

          const totalBuildings = Math.max(5, Math.round(count * densityFactor * 1.35));
          const buildings = [];

          // Signature Cairo Code contrasting architectural tone classes:
          // 0: Golden-Yellow, 1: Warm Orange, 2: Coral/Terracotta, 3: Deep Dark Slate/Green-Black
          for (let i = 0; i < totalBuildings; i++) {
            const depthRoll = i / totalBuildings;
            const depthLayer = depthRoll < 0.36 ? 0 : (depthRoll < 0.74 ? 1 : 2);

            const isHeroLeft = (i === Math.floor(totalBuildings * 0.42));
            const baseW = isHeroLeft
              ? rng.range(135, 185)
              : (depthLayer === 0 ? rng.range(48, 92) : (depthLayer === 1 ? rng.range(64, 130) : rng.range(72, 152)));

            const minH = depthLayer === 0 ? 115 : (depthLayer === 1 ? 155 : 135);
            const maxH = depthLayer === 0 ? 350 : (depthLayer === 1 ? 450 : 410);
            const rawH = isHeroLeft
              ? height * rng.range(0.66, 0.78) * heightScale
              : rng.range(minH, maxH) * heightScale * (1 - heightVar * 0.4 + rng.next() * heightVar * 0.95);
            const bHeight = Math.max(58, Math.min(height * 0.88, rawH));

            const lanePos = isHeroLeft
              ? rng.range(0.14, 0.28)
              : (i + rng.range(-0.32, 0.32)) / totalBuildings;
            const x = lanePos * (width + 100) - 50 - baseW * 0.5;
            const y = height - bHeight;

            const toneType = isHeroLeft ? 0 : rng.pick([0, 0, 1, 1, 2, 3]);
            const hueShift = rng.range(-state.colors.buildingsVar * 0.65, state.colors.buildingsVar * 0.65);
            const lightShift = depthLayer === 0
              ? rng.range(8, 22)
              : (depthLayer === 1 ? rng.range(-8, 10) : rng.range(-22, -4));

            // Bold interior geometric architectural sub-blocks (like the signature blue/dark-green blocks in Cairo Code)
            const subBlocks = [];
            const subCount = isHeroLeft ? rng.int(2, 4) : (rng.chance(0.65) ? rng.int(1, 3) : 0);
            for (let sb = 0; sb < subCount; sb++) {
              subBlocks.push({
                rx: rng.range(0.08, 0.52),
                ry: rng.range(0.08, 0.62),
                rw: rng.range(0.24, 0.58),
                rh: rng.range(0.14, 0.38),
                style: (isHeroLeft && sb === 0) ? 'blueFeature' : rng.pick(['darkCutout', 'accentSlab', 'blueFeature'])
              });
            }

            const isUnfinished = rng.chance(constructionProb);
            let scaffold = null;
            if (isUnfinished) {
              const cols = rng.int(3, 5);
              const rows = rng.int(2, 5);
              const cellH = rng.range(11, 15);
              const sideOverhang = rng.range(7, 15);
              const topRise = rows * cellH * rng.range(0.55, 0.82);
              const cells = [];
              for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                  cells.push({
                    r, c,
                    active: rng.chance(0.8),
                    hasXBrace: rng.chance(0.35),
                    hasPlankSlab: rng.chance(0.45),
                    hasSideBlock: (c === 0 || c === cols - 1) && rng.chance(0.38)
                  });
                }
              }
              scaffold = {
                cols, rows, cellH, sideOverhang, topRise,
                sideMount: rng.chance(0.5) ? -1 : 1,
                outRiggerLen: rng.range(14, 26),
                counterBlockH: rng.range(10, 18),
                cells
              };
            }

            const rooftopItems = [];
            if (rng.chance(0.48)) {
              const rebarCount = rng.int(3, 6);
              for (let k = 0; k < rebarCount; k++) {
                rooftopItems.push({ type: 'rebar', rx: (k + 0.5) / rebarCount, h: rng.range(10, 22) });
              }
            }
            if (rng.chance(0.45)) {
              rooftopItems.push({ type: 'room', rx: rng.range(0.15, 0.52), rw: rng.range(0.26, 0.44), rh: rng.range(14, 26) });
            }

            buildings.push({
              id: `BLD_${i}`,
              depthLayer,
              toneType,
              x, y, w: baseW, h: bHeight,
              hueShift, lightShift,
              subBlocks,
              isUnfinished,
              scaffold,
              rooftopItems
            });
          }

          return buildings;
        }
      }
