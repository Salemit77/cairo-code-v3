// 4. SYSTEM 2: BRIDGE GENERATOR (Layer 5)
      // -------------------------------------------------------------------
      class BridgeGenerator {
        static generate(state, width, height) {
          if (!state.bridges.enabled) return [];
          const rng = new SeededRNG(state.seed ^ (state.salts.bridges * 6151));
          const count = state.bridges.count;
          const style = state.bridges.style;
          const baseHeightRatio = state.bridges.height / 100;
          const lengthRatio = state.bridges.length / 100;
          const curvature = state.bridges.curvature / 100;
          const thickness = state.bridges.thickness;
          const numCols = state.bridges.columns;
          const placement = state.bridges.placement;

          const bridges = [];

          for (let i = 0; i < count; i++) {
            // Determine bridge spatial layer (0 = behind main city, 1 = midground, 2 = foreground)
            let depthLayer = 1;
            if (placement === 'foreground') depthLayer = 2;
            else if (placement === 'midground') depthLayer = 1;
            else if (placement === 'background') depthLayer = 0;
            else {
              depthLayer = (i % 2 === 0) ? 2 : 1;
            }

            // Vertical elevation spaced naturally so multiple bridges don't collide
            const spreadOffset = (i - (count - 1) / 2) * 0.11;
            const yRatio = Math.max(0.16, Math.min(0.84, 1 - baseHeightRatio + spreadOffset + rng.range(-0.03, 0.03)));
            const baseY = height * yRatio;

            // Span start & end X
            const spanW = width * lengthRatio;
            const marginX = (width - spanW) * 0.5;
            const startX = marginX - 60;
            const endX = width - marginX + 60;

            // Determine curve profile based on style
            let bridgeType = style;
            if (style === 'mixed') {
              bridgeType = ['straight', 'curved', 'ramps', 'multilevel'][i % 4];
            }

            let yStart = baseY;
            let yEnd = baseY;
            let ctrl1Y = baseY;
            let ctrl2Y = baseY;

            const curveAmp = curvature * 130;

            if (bridgeType === 'straight') {
              const slightSlope = rng.range(-15, 15) * curvature;
              yStart = baseY + slightSlope;
              yEnd = baseY - slightSlope;
              ctrl1Y = (yStart * 2 + yEnd) / 3;
              ctrl2Y = (yStart + yEnd * 2) / 3;
            } else if (bridgeType === 'curved') {
              const archDir = (i % 2 === 0 ? -1 : 1);
              ctrl1Y = baseY + archDir * curveAmp * 0.85;
              ctrl2Y = baseY - archDir * curveAmp * 0.45;
            } else if (bridgeType === 'ramps') {
              const rampDir = rng.chance(0.5) ? 1 : -1;
              yStart = baseY + rampDir * (45 + curveAmp * 0.5);
              yEnd = baseY - rampDir * (45 + curveAmp * 0.5);
              ctrl1Y = yStart - rampDir * curveAmp * 0.4;
              ctrl2Y = yEnd + rampDir * curveAmp * 0.4;
            } else if (bridgeType === 'multilevel') {
              const tierOffset = (i * 34) - ((count - 1) * 17);
              yStart = baseY + tierOffset;
              yEnd = baseY + tierOffset;
              ctrl1Y = yStart - curveAmp * 0.55;
              ctrl2Y = yEnd - curveAmp * 0.55;
            }

            const p0 = { x: startX, y: yStart };
            const p1 = { x: startX + (endX - startX) * 0.33, y: ctrl1Y };
            const p2 = { x: startX + (endX - startX) * 0.66, y: ctrl2Y };
            const p3 = { x: endX, y: yEnd };

            // Pre-sample spline for fast, accurate vehicle positioning & tangent angles
            const samples = 120;
            const lut = [];
            for (let s = 0; s <= samples; s++) {
              const t = s / samples;
              const pt = BridgeGenerator.evalBezier(p0, p1, p2, p3, t);
              const tan = BridgeGenerator.evalBezierTangent(p0, p1, p2, p3, t);
              const angle = Math.atan2(tan.y, tan.x);
              lut.push({ t, x: pt.x, y: pt.y, angle });
            }

            // Support columns positions along t in [0.06, 0.94]
            const columns = [];
            for (let c = 0; c < numCols; c++) {
              const ct = numCols === 1 ? 0.5 : 0.07 + (c / (numCols - 1)) * 0.86;
              const jitterT = Math.max(0.04, Math.min(0.96, ct + rng.range(-0.015, 0.015)));
              const pt = BridgeGenerator.evalBezier(p0, p1, p2, p3, jitterT);
              columns.push({
                t: jitterT,
                x: pt.x,
                topY: pt.y + thickness * 0.45,
                bottomY: height + 20,
                width: Math.max(10, thickness * 0.78)
              });
            }

            // Light poles along bridge
            const lightPoles = [];
            const numLights = Math.max(4, Math.round(numCols * 1.6));
            for (let l = 0; l < numLights; l++) {
              const lt = 0.04 + (l / Math.max(1, numLights - 1)) * 0.92;
              const pt = BridgeGenerator.evalBezier(p0, p1, p2, p3, lt);
              lightPoles.push({
                t: lt,
                x: pt.x,
                y: pt.y - thickness * 0.5,
                poleH: 22 + thickness * 0.4
              });
            }

            bridges.push({
              id: `BRG_${i}`,
              index: i,
              depthLayer,
              bridgeType,
              thickness: thickness * (depthLayer === 2 ? 1.08 : (depthLayer === 0 ? 0.82 : 1.0)),
              p0, p1, p2, p3,
              lut,
              columns,
              lightPoles
            });
          }

          return bridges;
        }

        static evalBezier(p0, p1, p2, p3, t) {
          const u = 1 - t;
          const tt = t * t, uu = u * u;
          const uuu = uu * u, ttt = tt * t;
          return {
            x: uuu * p0.x + 3 * uu * t * p1.x + 3 * u * tt * p2.x + ttt * p3.x,
            y: uuu * p0.y + 3 * uu * t * p1.y + 3 * u * tt * p2.y + ttt * p3.y
          };
        }

        static evalBezierTangent(p0, p1, p2, p3, t) {
          const u = 1 - t;
          return {
            x: 3 * u * u * (p1.x - p0.x) + 6 * u * t * (p2.x - p1.x) + 3 * t * t * (p3.x - p2.x),
            y: 3 * u * u * (p1.y - p0.y) + 6 * u * t * (p2.y - p1.y) + 3 * t * t * (p3.y - p2.y)
          };
        }

        static sampleBridge(bridge, t) {
          const clamped = Math.max(0, Math.min(1, t));
          const lut = bridge.lut;
          const idxFloat = clamped * (lut.length - 1);
          const i0 = Math.floor(idxFloat);
          const i1 = Math.min(lut.length - 1, i0 + 1);
          const frac = idxFloat - i0;
          const a = lut[i0], b = lut[i1];
          return {
            x: a.x + (b.x - a.x) * frac,
            y: a.y + (b.y - a.y) * frac,
            angle: a.angle + (b.angle - a.angle) * frac
          };
        }
      }

      // -------------------------------------------------------------------
