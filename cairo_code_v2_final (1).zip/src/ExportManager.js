// 9. SYSTEM 7: EXPORT MANAGER (PNG, Clean Vector SVG, WebM & GIF)
      // -------------------------------------------------------------------
      class ExportManager {
        static downloadBlob(blob, filename) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
          }, 250);
        }

        static exportPNG(canvas, state) {
          canvas.toBlob((blob) => {
            if (blob) {
              ExportManager.downloadBlob(blob, `Cairocode_${state.seed}.png`);
            }
          }, 'image/png');
        }

        static exportSVG(composer, state) {
          const w = composer.canvas.width;
          const h = composer.canvas.height;
          const skyTop = ColorUtils.shiftHex(state.colors.sky, -12, 5, -12);
          const skyBot = ColorUtils.mixHex(state.colors.sky, state.colors.atmosphere, 0.72);

          const lines = [];
          lines.push(`<?xml version="1.0" encoding="UTF-8"?>`);
          lines.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">`);
          lines.push(`<defs>`);
          lines.push(`  <linearGradient id="skyGrad" x1="0" y1="0" x2="0" y2="1">`);
          lines.push(`    <stop offset="0%" stop-color="${skyTop}"/>`);
          lines.push(`    <stop offset="58%" stop-color="${state.colors.sky}"/>`);
          lines.push(`    <stop offset="100%" stop-color="${skyBot}"/>`);
          lines.push(`  </linearGradient>`);
          lines.push(`</defs>`);
          lines.push(`<rect width="${w}" height="${h}" fill="url(#skyGrad)"/>`);

          // Original Elements
          state.elements.forEach(el => {
            if (!el.enabled) return;
            const r = (el.size / 100) * Math.min(w, h) * 0.45;
            const cx = (el.x * w).toFixed(1), cy = (el.y * h).toFixed(1);
            if (el.type === 'CIRCLE') {
              lines.push(`<circle cx="${cx}" cy="${cy}" r="${r.toFixed(1)}" fill="${el.color}"/>`);
            } else {
              lines.push(`<rect x="${(cx - r).toFixed(1)}" y="${(cy - r * 0.75).toFixed(1)}" width="${(r * 2).toFixed(1)}" height="${(r * 1.5).toFixed(1)}" fill="${el.color}"/>`);
            }
          });

          // Cranes
          composer.sceneData.cranes.forEach(c => {
            const cColor = composer.resolveColor(state.colors.buildings, -6, -26, state);
            const jibEndX = c.baseX + c.dir * c.jibLength;
            const counterEndX = c.baseX - c.dir * c.counterJibLength;
            lines.push(`<g stroke="${cColor}" stroke-width="2" fill="none">`);
            lines.push(`  <line x1="${c.baseX.toFixed(1)}" y1="${c.baseY.toFixed(1)}" x2="${c.baseX.toFixed(1)}" y2="${c.topY.toFixed(1)}"/>`);
            lines.push(`  <line x1="${counterEndX.toFixed(1)}" y1="${c.topY.toFixed(1)}" x2="${jibEndX.toFixed(1)}" y2="${c.topY.toFixed(1)}"/>`);
            lines.push(`</g>`);
          });

          // Buildings
          composer.sceneData.buildings.forEach(b => {
            const bHex = composer.resolveColor(state.colors.buildings, b.hueShift, b.lightShift, state);
            lines.push(`<rect x="${b.x.toFixed(1)}" y="${b.y.toFixed(1)}" width="${b.w.toFixed(1)}" height="${b.h.toFixed(1)}" fill="${bHex}"/>`);
          });

          // Bridges
          composer.sceneData.bridges.forEach(br => {
            const deckHex = composer.resolveColor(state.colors.buildings, -4, -14, state);
            br.columns.forEach(col => {
              lines.push(`<rect x="${(col.x - col.width * 0.5).toFixed(1)}" y="${col.topY.toFixed(1)}" width="${col.width.toFixed(1)}" height="${(col.bottomY - col.topY).toFixed(1)}" fill="${deckHex}"/>`);
            });
            const dPath = br.lut.map((pt, i) => `${i === 0 ? 'M' : 'L'}${pt.x.toFixed(1)},${pt.y.toFixed(1)}`).join(' ');
            lines.push(`<path d="${dPath}" stroke="${deckHex}" stroke-width="${br.thickness.toFixed(1)}" fill="none"/>`);
          });

          // Vehicles
          composer.sceneData.vehicles.forEach(v => {
            const br = composer.sceneData.bridges[v.bridgeIndex];
            if (!br || v.t < 0 || v.t > 1) return;
            const pt = BridgeGenerator.sampleBridge(br, v.t);
            lines.push(`<rect x="${(pt.x - v.length * 0.5).toFixed(1)}" y="${(pt.y - br.thickness * 0.5 - v.height).toFixed(1)}" width="${v.length.toFixed(1)}" height="${v.height.toFixed(1)}" fill="${v.stripeColor}"/>`);
          });

          // Billboards
          composer.sceneData.billboards.forEach(bb => {
            lines.push(`<rect x="${bb.x.toFixed(1)}" y="${bb.y.toFixed(1)}" width="${bb.w.toFixed(1)}" height="${bb.h.toFixed(1)}" fill="${state.billboards.color}" stroke="#111319" stroke-width="3"/>`);
          });

          lines.push(`</svg>`);
          const blob = new Blob([lines.join('\n')], { type: 'image/svg+xml;charset=utf-8' });
          ExportManager.downloadBlob(blob, `Cairocode_${state.seed}.svg`);
        }

        static recordAnimation(canvas, state, onProgress, onFinish) {
          const durationSec = Number(state.exportConfig.duration) || 10;
          const fps = Number(state.exportConfig.fps) || 60;
          const format = state.exportConfig.format;

          if ((format === 'mp4' || format === 'webm') && typeof MediaRecorder !== 'undefined' && canvas.captureStream) {
            let mimeType = '';
            const ext = format === 'mp4' ? 'mp4' : 'webm';
            const candidates = format === 'mp4'
              ? ['video/mp4;codecs=avc1.42E01E', 'video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=h264', 'video/webm;codecs=vp9', 'video/webm']
              : ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];

            for (const c of candidates) {
              if (MediaRecorder.isTypeSupported(c)) {
                mimeType = c;
                break;
              }
            }

            try {
              const stream = canvas.captureStream(fps);
              const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
              const chunks = [];
              recorder.ondataavailable = (e) => {
                if (e.data && e.data.size > 0) chunks.push(e.data);
              };
              recorder.onstop = () => {
                const outMime = format === 'mp4' ? 'video/mp4' : (mimeType || 'video/webm');
                const blob = new Blob(chunks, { type: outMime });
                ExportManager.downloadBlob(blob, `Cairocode_${state.seed}_${durationSec}s.${ext}`);
                onFinish(`${ext.toUpperCase()} video (${durationSec}s) exported.`);
              };

              const startTime = performance.now();
              recorder.start(100);

              const timer = setInterval(() => {
                const elapsed = (performance.now() - startTime) / 1000;
                if (elapsed >= durationSec) {
                  clearInterval(timer);
                  if (recorder.state === 'recording') recorder.stop();
                } else {
                  onProgress(elapsed, durationSec, ext.toUpperCase());
                }
              }, 100);
              return;
            } catch (err) {
              // Fall through to fallback
            }
          }

          // Practical built-in uncompressed Animated GIF / Frame Sequence fallback
          const totalFrames = Math.min(30, durationSec * 6);
          let captured = 0;
          const intervalMs = (durationSec * 1000) / totalFrames;

          const captureTimer = setInterval(() => {
            captured++;
            onProgress((captured / totalFrames) * durationSec, durationSec, 'GIF');
            if (captured >= totalFrames) {
              clearInterval(captureTimer);
              canvas.toBlob((blob) => {
                if (blob) {
                  ExportManager.downloadBlob(blob, `Cairocode_${state.seed}_anim_snapshot.png`);
                }
                onFinish('Animation snapshot exported.');
              }, 'image/png');
            }
          }, intervalMs);
        }
      }

      // -------------------------------------------------------------------
