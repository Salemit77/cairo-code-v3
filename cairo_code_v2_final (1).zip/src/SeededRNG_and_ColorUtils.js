class SeededRNG {
        constructor(seed) {
          this.state = (seed >>> 0) || 1;
        }
        next() {
          let t = (this.state += 0x6D2B79F5);
          t = Math.imul(t ^ (t >>> 15), t | 1);
          t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
          return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        }
        range(min, max) {
          return min + this.next() * (max - min);
        }
        int(min, max) {
          return Math.floor(this.range(min, max + 1));
        }
        pick(arr) {
          return arr[Math.floor(this.next() * arr.length)];
        }
        chance(prob) {
          return this.next() < prob;
        }
      }

      const ColorUtils = {
        hexToRgb(hex) {
          const clean = (hex || '#e07a38').replace('#', '');
          const num = parseInt(clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean, 16) || 0;
          return {
            r: (num >> 16) & 255,
            g: (num >> 8) & 255,
            b: num & 255
          };
        },
        rgbToHex(r, g, b) {
          const clamp = (v) => Math.max(0, Math.min(255, Math.round(v)));
          return '#' + [clamp(r), clamp(g), clamp(b)].map(x => x.toString(16).padStart(2, '0')).join('');
        },
        rgbToHsl(r, g, b) {
          r /= 255; g /= 255; b /= 255;
          const max = Math.max(r, g, b), min = Math.min(r, g, b);
          let h = 0, s = 0, l = (max + min) / 2;
          if (max !== min) {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
              case r: h = (g - b) / d + (g < b ? 6 : 0); break;
              case g: h = (b - r) / d + 2; break;
              case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
          }
          return { h: h * 360, s: s * 100, l: l * 100 };
        },
        hslToHex(h, s, l) {
          h = ((h % 360) + 360) % 360;
          s = Math.max(0, Math.min(100, s)) / 100;
          l = Math.max(0, Math.min(100, l)) / 100;
          const c = (1 - Math.abs(2 * l - 1)) * s;
          const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
          const m = l - c / 2;
          let r = 0, g = 0, b = 0;
          if (h < 60) { r = c; g = x; }
          else if (h < 120) { r = x; g = c; }
          else if (h < 180) { g = c; b = x; }
          else if (h < 240) { g = x; b = c; }
          else if (h < 300) { r = x; b = c; }
          else { r = c; b = x; }
          return this.rgbToHex((r + m) * 255, (g + m) * 255, (b + m) * 255);
        },
        shiftHex(hex, dh, ds, dl) {
          const rgb = this.hexToRgb(hex);
          const hsl = this.rgbToHsl(rgb.r, rgb.g, rgb.b);
          return this.hslToHex(hsl.h + dh, hsl.s + ds, hsl.l + dl);
        },
        mixHex(hex1, hex2, t) {
          const c1 = this.hexToRgb(hex1);
          const c2 = this.hexToRgb(hex2);
          return this.rgbToHex(
            c1.r + (c2.r - c1.r) * t,
            c1.g + (c2.g - c1.g) * t,
            c1.b + (c2.b - c1.b) * t
          );
        },
        rgba(hex, alpha) {
          const c = this.hexToRgb(hex);
          return `rgba(${c.r}, ${c.g}, ${c.b}, ${alpha})`;
        }
      };

      // -------------------------------------------------------------------
