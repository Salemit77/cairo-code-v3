// 2. UI STATE MANAGEMENT & PRESETS
      // -------------------------------------------------------------------
      const respectsReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      const DEFAULT_STATE = {
        seed: 4170,
        salts: {
          buildings: 101,
          bridges: 202,
          traffic: 303,
          billboards: 404,
          cranes: 505,
          elements: 606
        },
        activePresetName: 'Downtown Cairo',
        nightMode: false,
        zenMode: false,

        // Animation & Live Preview
        animation: {
          playing: !respectsReducedMotion,
          livePreview: true,
          speed: 1.0,
          trafficMotion: true,
          billboardMotion: true,
          craneMotion: true,
          atmosphereMotion: false
        },

        // System Config (City)
        sysconfig: {
          ratio: '16:9',
          buildingCount: 18,
          buildingHeight: 65,
          buildingDensity: 100,
          heightVariation: 65,
          archRandomness: 65
        },

        // Bridges & Flyovers
        bridges: {
          enabled: true,
          style: 'mixed',
          count: 2,
          height: 34,
          length: 100,
          curvature: 36,
          thickness: 18,
          columns: 6,
          placement: 'layered',
          lights: true
        },

        // Animated Traffic
        traffic: {
          enabled: true,
          density: 16,
          speed: 1.0,
          size: 1.0,
          mix: 'cairoMix',
          direction: 'both'
        },

        // Advertising Billboards
        billboards: {
          enabled: true,
          count: 6,
          size: 1.0,
          placement: 'mixed',
          color: '#ff5500',
          accent: '#ffe600',
          graphics: 'mixed',
          text: '',
          ledAnim: true
        },

        // Construction Cranes
        cranes: {
          enabled: true,
          count: 3,
          height: 110,
          armLength: 95,
          position: 'mixed',
          constructionDensity: 58,
          motion: true
        },

        // Camera
        camera: {
          zoom: 100,
          pan: 0,
          tilt: 0
        },

        // Colors
        colors: {
          mode: 'Absolute',
          buildings: '#e07a38',
          buildingsVar: 35,
          atmosphere: '#f49d52',
          atmosphereVar: 30,
          sky: '#c8b6e2',
          skyVar: 40
        },

        // Atmosphere
        atmosphere: {
          fogOpacity: 38,
          fogHeight: 48
        },

        // Elements (Exact Original Cairo Code initial composition: Left Blue Rect + Upper-Right Yellow, Magenta & Lime Circles)
        elements: [
          { id: 'el_1', type: 'RECT', enabled: true, color: '#1d4ed8', size: 28, x: 0.22, y: 0.54 },
          { id: 'el_2', type: 'CIRCLE', enabled: true, color: '#facc15', size: 36, x: 0.76, y: 0.25 },
          { id: 'el_3', type: 'CIRCLE', enabled: true, color: '#ec4899', size: 21, x: 0.83, y: 0.29 },
          { id: 'el_4', type: 'CIRCLE', enabled: true, color: '#22c55e', size: 13, x: 0.79, y: 0.43 }
        ],

        // Distortion (Exact Original Cairo Code opening defaults: XY Glitch ~85%, Pixelate 0%, Scatter ~60%)
        distortion: {
          xyGlitch: 85,
          pixelate: 0,
          scatter: 60
        },

        // Effects (Exact Original Cairo Code opening defaults: Ink Bleed ~33%, Film Grain ~50%, Rough Edge ~55%, Chromatic ~28%)
        effects: {
          inkBleed: 33,
          filmGrain: 50,
          roughEdge: 55,
          bloom: 0,
          chromatic: 28,
          brightness: 0,
          contrast: 0,
          hue: 0,
          saturation: 0,
          temperature: 0,
          tint: 0
        },

        // Data Visualization (Exact Original Cairo Code opening defaults: Detection ~76%, After Distortion)
        dataviz: {
          enable: true,
          apply: 'After Distortion',
          detection: 76,
          outline: true,
          outlineColor: '#ff2a6d',
          outlineWeight: 1.4,
          fill: true,
          fillColor: '#0a0b0e',
          fillOpacity: 22,
          text: true,
          textColor: '#ff2a6d',
          textSize: 9,
          lines: true,
          linesColor: '#6366f1',
          connection: 'Nearest',
          lineStyle: 'Curved',
          curvature: 48
        },

        // Export (MP4 default, up to 30s)
        exportConfig: {
          format: 'mp4',
          duration: 10,
          resolution: 'canvas',
          fps: 60,
          speed: 1.0
        }
      };

      const PRESETS = {
        zenMode: {
          name: 'Zen Mode',
          nightMode: false,
          zenMode: true,
          animation: { playing: true, livePreview: true, speed: 0.3, trafficMotion: true, billboardMotion: false, craneMotion: true, atmosphereMotion: false },
          sysconfig: { ratio: '16:9', buildingCount: 12, buildingHeight: 34, buildingDensity: 80, heightVariation: 35, archRandomness: 40 },
          bridges: { enabled: true, style: 'curved', count: 2, height: 24, length: 100, curvature: 28, thickness: 18, columns: 6, placement: 'layered', lights: false },
          traffic: { enabled: true, density: 28, speed: 0.4, size: 1.0, mix: 'cairoMix', direction: 'both' },
          billboards: { enabled: false, count: 1, size: 0.8, placement: 'rooftop', color: '#d97706', accent: '#fde68a', graphics: 'geometric', text: '', ledAnim: false },
          cranes: { enabled: true, count: 1, height: 65, armLength: 70, position: 'background', constructionDensity: 15, motion: true },
          colors: { mode: 'Absolute', buildings: '#7c2d12', buildingsVar: 22, atmosphere: '#f97316', atmosphereVar: 25, sky: '#fdba74', skyVar: 35 },
          atmosphere: { fogOpacity: 44, fogHeight: 42 },
          elements: [
            { id: 'el_sun', type: 'CIRCLE', enabled: true, color: '#fef08a', size: 36, x: 0.50, y: 0.34 }
          ],
          distortion: { xyGlitch: 0, pixelate: 0, scatter: 0 },
          effects: { inkBleed: 4, filmGrain: 10, roughEdge: 0, bloom: 18, chromatic: 0, brightness: 0, contrast: 0, hue: 0, saturation: 5, temperature: 12, tint: 0 },
          dataviz: { enable: false }
        },
        downtownCairo: {
          name: 'Downtown Cairo',
          nightMode: false,
        zenMode: false,
          sysconfig: { ratio: '16:9', buildingCount: 22, buildingHeight: 74, buildingDensity: 115, heightVariation: 70, archRandomness: 65 },
          bridges: { enabled: true, style: 'mixed', count: 2, height: 32, length: 100, curvature: 32, thickness: 18, columns: 6, placement: 'layered', lights: true },
          traffic: { enabled: true, density: 18, speed: 1.0, size: 1.0, mix: 'cairoMix', direction: 'both' },
          billboards: { enabled: true, count: 7, size: 1.05, placement: 'mixed', color: '#ff5500', accent: '#ffe600', graphics: 'mixed', text: '', ledAnim: true },
          cranes: { enabled: true, count: 2, height: 105, armLength: 90, position: 'mixed', constructionDensity: 35, motion: true },
          colors: { mode: 'Absolute', buildings: '#e07a38', buildingsVar: 35, atmosphere: '#f49d52', atmosphereVar: 30, sky: '#c8b6e2', skyVar: 40 },
          atmosphere: { fogOpacity: 38, fogHeight: 48 },
          distortion: { xyGlitch: 85, pixelate: 0, scatter: 60 },
          effects: { inkBleed: 33, filmGrain: 50, roughEdge: 55, bloom: 0, chromatic: 28, brightness: 0, contrast: 0, hue: 0, saturation: 0, temperature: 0, tint: 0 },
          dataviz: { enable: true, detection: 76, outline: true, outlineColor: '#ff2a6d', lines: true, linesColor: '#6366f1', connection: 'Nearest', lineStyle: 'Curved' }
        },
        cairoRingRoad: {
          name: 'Cairo Ring Road',
          nightMode: false,
        zenMode: false,
          sysconfig: { ratio: '16:9', buildingCount: 16, buildingHeight: 54, buildingDensity: 95, heightVariation: 55, archRandomness: 60 },
          bridges: { enabled: true, style: 'multilevel', count: 4, height: 46, length: 100, curvature: 54, thickness: 22, columns: 9, placement: 'layered', lights: true },
          traffic: { enabled: true, density: 30, speed: 1.35, size: 1.05, mix: 'microbusHeavy', direction: 'both' },
          billboards: { enabled: true, count: 9, size: 1.2, placement: 'highway', color: '#e11d48', accent: '#facc15', graphics: 'typography', text: '', ledAnim: true },
          cranes: { enabled: true, count: 3, height: 115, armLength: 100, position: 'background', constructionDensity: 50, motion: true },
          colors: { mode: 'Absolute', buildings: '#d97736', buildingsVar: 40, atmosphere: '#fb923c', atmosphereVar: 35, sky: '#fde68a', skyVar: 30 },
          atmosphere: { fogOpacity: 45, fogHeight: 52 },
          distortion: { xyGlitch: 0, pixelate: 0, scatter: 0 },
          dataviz: { enable: true, detection: 50, outline: true, outlineColor: '#06b6d4', lines: true, linesColor: '#f59e0b', connection: 'Sequential', lineStyle: 'Curved' }
        },
        urbanConstruction: {
          name: 'Urban Construction',
          nightMode: false,
        zenMode: false,
          sysconfig: { ratio: '16:9', buildingCount: 20, buildingHeight: 80, buildingDensity: 110, heightVariation: 80, archRandomness: 75 },
          bridges: { enabled: true, style: 'ramps', count: 2, height: 30, length: 95, curvature: 24, thickness: 19, columns: 7, placement: 'midground', lights: true },
          traffic: { enabled: true, density: 14, speed: 0.9, size: 1.05, mix: 'commercial', direction: 'both' },
          billboards: { enabled: true, count: 4, size: 0.95, placement: 'rooftop', color: '#f97316', accent: '#ffffff', graphics: 'geometric', text: '', ledAnim: true },
          cranes: { enabled: true, count: 7, height: 155, armLength: 135, position: 'mixed', constructionDensity: 85, motion: true },
          colors: { mode: 'Tint', buildings: '#c26d38', buildingsVar: 45, atmosphere: '#eab308', atmosphereVar: 40, sky: '#e2d4f0', skyVar: 35 },
          atmosphere: { fogOpacity: 50, fogHeight: 58 },
          distortion: { xyGlitch: 0, pixelate: 0, scatter: 0 },
          dataviz: { enable: true, detection: 55, outline: true, outlineColor: '#f97316', lines: true, linesColor: '#38bdf8', connection: 'Hub (Largest)', lineStyle: 'Straight' }
        },
        cairoAtNight: {
          name: 'Cairo at Night',
          nightMode: true,
          sysconfig: { ratio: '16:9', buildingCount: 24, buildingHeight: 78, buildingDensity: 120, heightVariation: 70, archRandomness: 65 },
          bridges: { enabled: true, style: 'curved', count: 3, height: 38, length: 100, curvature: 45, thickness: 18, columns: 7, placement: 'layered', lights: true },
          traffic: { enabled: true, density: 24, speed: 1.15, size: 1.0, mix: 'cairoMix', direction: 'both' },
          billboards: { enabled: true, count: 8, size: 1.15, placement: 'led', color: '#00f5d4', accent: '#ff007f', graphics: 'ledMatrix', text: '', ledAnim: true },
          cranes: { enabled: true, count: 3, height: 125, armLength: 105, position: 'background', constructionDensity: 40, motion: true },
          colors: { mode: 'Absolute', buildings: '#1e293b', buildingsVar: 45, atmosphere: '#312e81', atmosphereVar: 50, sky: '#090d16', skyVar: 25 },
          atmosphere: { fogOpacity: 42, fogHeight: 45 },
          effects: { bloom: 38, filmGrain: 18, contrast: 15 },
          distortion: { xyGlitch: 0, pixelate: 0, scatter: 0 },
          dataviz: { enable: true, detection: 45, outline: true, outlineColor: '#00f5d4', lines: true, linesColor: '#ff2a6d', connection: 'Nearest', lineStyle: 'Curved' }
        },
        goldenHour: {
          name: 'Golden Hour',
          nightMode: false,
        zenMode: false,
          sysconfig: { ratio: '16:9', buildingCount: 14, buildingHeight: 60, buildingDensity: 100, heightVariation: 60, archRandomness: 55 },
          bridges: { enabled: true, style: 'straight', count: 2, height: 30, length: 100, curvature: 20, thickness: 16, columns: 5, placement: 'layered', lights: true },
          traffic: { enabled: true, density: 14, speed: 1.0, size: 1.0, mix: 'cairoMix', direction: 'both' },
          billboards: { enabled: true, count: 4, size: 1.0, placement: 'mixed', color: '#f59e0b', accent: '#fef08a', graphics: 'mixed', text: '', ledAnim: true },
          cranes: { enabled: true, count: 2, height: 95, armLength: 85, position: 'background', constructionDensity: 30, motion: true },
          colors: { mode: 'Absolute', buildings: '#ea580c', buildingsVar: 30, atmosphere: '#fb923c', atmosphereVar: 35, sky: '#c4b5fd', skyVar: 45 },
          atmosphere: { fogOpacity: 45, fogHeight: 55 },
          distortion: { xyGlitch: 0, pixelate: 0, scatter: 0 }
        },
        void: {
          name: 'Void',
          nightMode: true,
          sysconfig: { ratio: '16:9', buildingCount: 19, buildingHeight: 82, buildingDensity: 110, heightVariation: 75, archRandomness: 70 },
          colors: { mode: 'Tint', buildings: '#27272a', buildingsVar: 20, atmosphere: '#18181b', atmosphereVar: 20, sky: '#09090b', skyVar: 10 },
          atmosphere: { fogOpacity: 50, fogHeight: 40 },
          dataviz: { enable: true, detection: 70, outline: true, outlineColor: '#ffffff', lines: true, linesColor: '#71717a', connection: 'Hub (Largest)', lineStyle: 'Straight' }
        },
        redAlert: {
          name: 'Red Alert',
          nightMode: false,
        zenMode: false,
          sysconfig: { ratio: '16:9', buildingCount: 21, buildingHeight: 75, buildingDensity: 115, heightVariation: 70, archRandomness: 70 },
          colors: { mode: 'Tint', buildings: '#991b1b', buildingsVar: 40, atmosphere: '#ef4444', atmosphereVar: 30, sky: '#450a0a', skyVar: 25 },
          distortion: { xyGlitch: 16, pixelate: 0, scatter: 8 },
          dataviz: { enable: true, detection: 65, outline: true, outlineColor: '#fecaca', lines: true, linesColor: '#f87171', connection: 'Nearest', lineStyle: 'Straight' }
        },
        candyScatter: {
          name: 'Candy Scatter',
          nightMode: false,
        zenMode: false,
          colors: { mode: 'Flat', buildings: '#f472b6', buildingsVar: 65, atmosphere: '#38bdf8', atmosphereVar: 50, sky: '#fef08a', skyVar: 45 },
          distortion: { xyGlitch: 6, pixelate: 0, scatter: 18 }
        },
        vaporwave: {
          name: 'Vaporwave',
          nightMode: true,
          colors: { mode: 'Tint', buildings: '#7c3aed', buildingsVar: 55, atmosphere: '#ec4899', atmosphereVar: 50, sky: '#0f172a', skyVar: 40 },
          effects: { bloom: 32, chromatic: 22, filmGrain: 16 },
          dataviz: { enable: true, detection: 60, outline: true, outlineColor: '#22d3ee', lines: true, linesColor: '#f472b6', connection: 'Sequential', lineStyle: 'Curved' }
        }
      };

      // Deep clone helper
      function deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
      }

      const state = deepClone(DEFAULT_STATE);

      // -------------------------------------------------------------------
