// 10. INITIALIZATION, ANIMATION CONTROLLER & UI BINDINGS
      // -------------------------------------------------------------------
      const canvas = document.getElementById('skylineCanvas');
      const composer = new SceneComposer(canvas);

      function updateCanvasAspectRatio() {
        const ratio = state.sysconfig.ratio;
        const is1080 = state.exportConfig.resolution === '1080p';
        if (ratio === '1:1') {
          canvas.width = is1080 ? 1080 : 720;
          canvas.height = is1080 ? 1080 : 720;
        } else if (ratio === '4:5') {
          canvas.width = is1080 ? 1080 : 720;
          canvas.height = is1080 ? 1350 : 900;
        } else if (ratio === '9:16') {
          canvas.width = is1080 ? 1080 : 540;
          canvas.height = is1080 ? 1920 : 960;
        } else {
          canvas.width = is1080 ? 1920 : 960;
          canvas.height = is1080 ? 1080 : 540;
        }
        composer.rebuildAll(state);
      }

      // Sync UI controls from current state
      function syncUIFromState() {
        const setVal = (id, val) => {
          const el = document.getElementById(id);
          if (el) el.value = val;
        };
        const setChk = (id, val) => {
          const el = document.getElementById(id);
          if (el) el.checked = Boolean(val);
        };
        const setTxt = (id, txt) => {
          const el = document.getElementById(id);
          if (el) el.textContent = txt;
        };

        setVal('headerSeedInput', state.seed);
        setTxt('activePresetBadge', `PRESET: ${state.activePresetName}`);

        // Animation
        setChk('ctrl_livePreview', state.animation.livePreview);
        setVal('ctrl_animSpeed', state.animation.speed);
        setTxt('val_animSpeed', `${state.animation.speed.toFixed(1)}x`);
        setChk('ctrl_motionTraffic', state.animation.trafficMotion);
        setChk('ctrl_motionBillboards', state.animation.billboardMotion);
        setChk('ctrl_motionCranes', state.animation.craneMotion);
        setChk('ctrl_motionAtmosphere', state.animation.atmosphereMotion);

        const playLabel = state.animation.playing ? 'PAUSE ANIMATION' : 'PLAY ANIMATION';
        setTxt('panelPlayPauseBtn', playLabel);
        setTxt('canvasPlayIcon', '');
        setTxt('canvasPlayText', state.animation.playing ? 'PAUSE' : 'PLAY');

        // System Config
        setVal('ctrl_ratio', state.sysconfig.ratio);
        setVal('ctrl_buildingCount', state.sysconfig.buildingCount);
        setTxt('val_buildingCount', state.sysconfig.buildingCount);
        setVal('ctrl_buildingHeight', state.sysconfig.buildingHeight);
        setTxt('val_buildingHeight', state.sysconfig.buildingHeight);
        setVal('ctrl_buildingDensity', state.sysconfig.buildingDensity);
        setTxt('val_buildingDensity', `${state.sysconfig.buildingDensity}%`);
        setVal('ctrl_heightVariation', state.sysconfig.heightVariation);
        setTxt('val_heightVariation', `${state.sysconfig.heightVariation}%`);
        setVal('ctrl_archRandomness', state.sysconfig.archRandomness);
        setTxt('val_archRandomness', `${state.sysconfig.archRandomness}%`);

        // Bridges
        setChk('ctrl_bridgesEnabled', state.bridges.enabled);
        setChk('quickToggleBridges', state.bridges.enabled);
        setVal('ctrl_bridgeStyle', state.bridges.style);
        setVal('ctrl_bridgeCount', state.bridges.count);
        setTxt('val_bridgeCount', state.bridges.count);
        setVal('ctrl_bridgeHeight', state.bridges.height);
        setTxt('val_bridgeHeight', `${state.bridges.height}%`);
        setVal('ctrl_bridgeLength', state.bridges.length);
        setTxt('val_bridgeLength', `${state.bridges.length}%`);
        setVal('ctrl_bridgeCurvature', state.bridges.curvature);
        setTxt('val_bridgeCurvature', state.bridges.curvature);
        setVal('ctrl_roadThickness', state.bridges.thickness);
        setTxt('val_roadThickness', `${state.bridges.thickness}px`);
        setVal('ctrl_supportColumns', state.bridges.columns);
        setTxt('val_supportColumns', state.bridges.columns);
        setVal('ctrl_bridgePlacement', state.bridges.placement);
        setChk('ctrl_bridgeLights', state.bridges.lights);

        // Traffic
        setChk('ctrl_trafficEnabled', state.traffic.enabled);
        setChk('quickToggleTraffic', state.traffic.enabled);
        setVal('ctrl_trafficDensity', state.traffic.density);
        setTxt('val_trafficDensity', state.traffic.density);
        setVal('ctrl_trafficSpeed', state.traffic.speed);
        setTxt('val_trafficSpeed', `${Number(state.traffic.speed).toFixed(1)}x`);
        setVal('ctrl_vehicleSize', state.traffic.size);
        setTxt('val_vehicleSize', `${Number(state.traffic.size).toFixed(2)}x`);
        setVal('ctrl_vehicleMix', state.traffic.mix);
        setVal('ctrl_trafficDirection', state.traffic.direction);

        // Billboards
        setChk('ctrl_billboardsEnabled', state.billboards.enabled);
        setChk('quickToggleBillboards', state.billboards.enabled);
        setVal('ctrl_billboardCount', state.billboards.count);
        setTxt('val_billboardCount', state.billboards.count);
        setVal('ctrl_billboardSize', state.billboards.size);
        setTxt('val_billboardSize', `${Number(state.billboards.size).toFixed(2)}x`);
        setVal('ctrl_billboardPlacement', state.billboards.placement);
        setVal('ctrl_billboardColor', state.billboards.color);
        setVal('ctrl_billboardAccent', state.billboards.accent);
        setVal('ctrl_billboardGraphics', state.billboards.graphics);
        setVal('ctrl_billboardText', state.billboards.text);
        setChk('ctrl_billboardLedAnim', state.billboards.ledAnim);

        // Cranes
        setChk('ctrl_cranesEnabled', state.cranes.enabled);
        setChk('quickToggleCranes', state.cranes.enabled);
        setVal('ctrl_craneCount', state.cranes.count);
        setTxt('val_craneCount', state.cranes.count);
        setVal('ctrl_craneHeight', state.cranes.height);
        setTxt('val_craneHeight', state.cranes.height);
        setVal('ctrl_craneArmLength', state.cranes.armLength);
        setTxt('val_craneArmLength', state.cranes.armLength);
        setVal('ctrl_cranePosition', state.cranes.position);
        setVal('ctrl_constructionDensity', state.cranes.constructionDensity);
        setTxt('val_constructionDensity', `${state.cranes.constructionDensity}%`);
        setChk('ctrl_craneMotion', state.cranes.motion);

        // Camera
        setVal('ctrl_zoom', state.camera.zoom);
        setTxt('val_zoom', `${state.camera.zoom}%`);
        setVal('ctrl_pan', state.camera.pan);
        setTxt('val_pan', state.camera.pan);
        setVal('ctrl_tilt', state.camera.tilt);
        setTxt('val_tilt', state.camera.tilt);

        // Colors
        setVal('ctrl_colorMode', state.colors.mode);
        setVal('ctrl_colorBuildings', state.colors.buildings);
        setVal('ctrl_colorBuildingsVar', state.colors.buildingsVar);
        setVal('ctrl_colorAtmosphere', state.colors.atmosphere);
        setVal('ctrl_colorAtmosphereVar', state.colors.atmosphereVar);
        setVal('ctrl_colorSky', state.colors.sky);
        setVal('ctrl_colorSkyVar', state.colors.skyVar);

        // Atmosphere
        setVal('ctrl_fogOpacity', state.atmosphere.fogOpacity);
        setTxt('val_fogOpacity', `${state.atmosphere.fogOpacity}%`);
        setVal('ctrl_fogHeight', state.atmosphere.fogHeight);
        setTxt('val_fogHeight', `${state.atmosphere.fogHeight}%`);

        // Distortion
        setVal('ctrl_xyGlitch', state.distortion.xyGlitch);
        setTxt('val_xyGlitch', state.distortion.xyGlitch);
        setVal('ctrl_pixelate', state.distortion.pixelate);
        setTxt('val_pixelate', state.distortion.pixelate);
        setVal('ctrl_scatter', state.distortion.scatter);
        setTxt('val_scatter', state.distortion.scatter);

        // Effects
        setVal('ctrl_inkBleed', state.effects.inkBleed);
        setVal('ctrl_filmGrain', state.effects.filmGrain);
        setVal('ctrl_roughEdge', state.effects.roughEdge);
        setVal('ctrl_bloom', state.effects.bloom);
        setVal('ctrl_chromatic', state.effects.chromatic);
        setVal('ctrl_brightness', state.effects.brightness);
        setVal('ctrl_contrast', state.effects.contrast);
        setVal('ctrl_hue', state.effects.hue);
        setVal('ctrl_saturation', state.effects.saturation);
        setVal('ctrl_temperature', state.effects.temperature);
        setVal('ctrl_tintEffect', state.effects.tint);

        // Data Viz
        setChk('ctrl_dvEnable', state.dataviz.enable);
        setVal('ctrl_dvApply', state.dataviz.apply);
        setVal('ctrl_dvDetection', state.dataviz.detection);
        setChk('ctrl_dvOutline', state.dataviz.outline);
        setVal('ctrl_dvOutlineColor', state.dataviz.outlineColor);
        setVal('ctrl_dvOutlineWeight', state.dataviz.outlineWeight);
        setChk('ctrl_dvFill', state.dataviz.fill);
        setVal('ctrl_dvFillColor', state.dataviz.fillColor);
        setVal('ctrl_dvFillOpacity', state.dataviz.fillOpacity);
        setChk('ctrl_dvText', state.dataviz.text);
        setVal('ctrl_dvTextColor', state.dataviz.textColor);
        setVal('ctrl_dvTextSize', state.dataviz.textSize);
        setChk('ctrl_dvLines', state.dataviz.lines);
        setVal('ctrl_dvLinesColor', state.dataviz.linesColor);
        setVal('ctrl_dvConnection', state.dataviz.connection);
        setVal('ctrl_dvLineStyle', state.dataviz.lineStyle);
        setVal('ctrl_dvCurvature', state.dataviz.curvature);

        renderElementsListUI();
        updateTelemetryCounter();
      }

      function updateTelemetryCounter() {
        const bCount = composer.sceneData.buildings.length;
        const brCount = composer.sceneData.bridges.length;
        const vCount = composer.sceneData.vehicles.length;
        const el = document.getElementById('entityCounter');
        if (el) {
          el.textContent = `${bCount} BLD · ${brCount} BRG · ${vCount} VEH`;
        }
      }

      // Render dynamic ELEMENTS rows (Original Cairo Code feature)
      function renderElementsListUI() {
        const container = document.getElementById('elementsListContainer');
        if (!container) return;
        container.innerHTML = '';
        state.elements.forEach((item, idx) => {
          const row = document.createElement('div');
          row.className = 'ctrl-row bg-[#141720] px-2 py-1 rounded border border-[#222634]';
          row.innerHTML = `
            <div class="flex items-center gap-1.5">
              <input type="checkbox" data-el-idx="${idx}" class="el-toggle accent-blue-500" ${item.enabled ? 'checked' : ''} />
              <span class="font-mono-code text-[11px] text-gray-300 w-12">${item.type}</span>
            </div>
            <input type="color" data-el-idx="${idx}" class="el-color" value="${item.color}" />
            <input type="range" data-el-idx="${idx}" class="el-size w-20" min="8" max="80" value="${item.size}" />
            <button type="button" data-el-idx="${idx}" class="el-remove text-gray-400 hover:text-red-400 font-mono-code px-1">×</button>
          `;
          container.appendChild(row);
        });

        container.querySelectorAll('.el-toggle').forEach(chk => {
          chk.addEventListener('change', (e) => {
            const i = Number(e.target.getAttribute('data-el-idx'));
            if (state.elements[i]) { state.elements[i].enabled = e.target.checked; composer.invalidateStatic(); }
          });
        });
        container.querySelectorAll('.el-color').forEach(col => {
          col.addEventListener('input', (e) => {
            const i = Number(e.target.getAttribute('data-el-idx'));
            if (state.elements[i]) { state.elements[i].color = e.target.value; composer.invalidateStatic(); }
          });
        });
        container.querySelectorAll('.el-size').forEach(rng => {
          rng.addEventListener('input', (e) => {
            const i = Number(e.target.getAttribute('data-el-idx'));
            if (state.elements[i]) { state.elements[i].size = Number(e.target.value); composer.invalidateStatic(); }
          });
        });
        container.querySelectorAll('.el-remove').forEach(btn => {
          btn.addEventListener('click', (e) => {
            const i = Number(e.currentTarget.getAttribute('data-el-idx'));
            state.elements.splice(i, 1); composer.invalidateStatic();
            renderElementsListUI();
          });
        });
      }

      // Bind all UI controls to state without restarting unrelated scene systems
      function bindControls() {
        const onInput = (id, fn) => {
          const el = document.getElementById(id);
          if (el) el.addEventListener('input', fn);
        };
        const onChange = (id, fn) => {
          const el = document.getElementById(id);
          if (el) el.addEventListener('change', fn);
        };
        const onClick = (id, fn) => {
          const el = document.getElementById(id);
          if (el) el.addEventListener('click', fn);
        };

        // Seed & Update
        onChange('headerSeedInput', (e) => {
          state.seed = Math.max(1, parseInt(e.target.value, 10) || 1);
          composer.rebuildAll(state);
          updateTelemetryCounter();
        });
        const randomizeFullComposition = () => {
          state.seed = Math.floor(1000 + Math.random() * 900000);
          const rng = new SeededRNG(state.seed ^ (Date.now() & 0xffffff));

          // Randomize all subsystem salts
          state.salts.buildings = rng.int(100, 9999);
          state.salts.bridges = rng.int(100, 9999);
          state.salts.traffic = rng.int(100, 9999);
          state.salts.billboards = rng.int(100, 9999);
          state.salts.cranes = rng.int(100, 9999);
          state.salts.elements = rng.int(100, 9999);

          if (state.zenMode) {
            // Randomize sunset color palettes and sun position/size in Zen Mode
            const zenPalettes = [
              { buildings: '#7c2d12', atmosphere: '#f97316', sky: '#fdba74', sun: '#fef08a' },
              { buildings: '#4c1d95', atmosphere: '#fb7185', sky: '#fda4af', sun: '#fde047' },
              { buildings: '#581c87', atmosphere: '#f59e0b', sky: '#fcd34d', sun: '#fffbeb' },
              { buildings: '#7f1d1d', atmosphere: '#ea580c', sky: '#fdba74', sun: '#fef9c3' },
              { buildings: '#312e81', atmosphere: '#f43f5e', sky: '#fbcfe8', sun: '#fef08a' },
              { buildings: '#451a03', atmosphere: '#d97706', sky: '#fde68a', sun: '#ffffff' }
            ];
            const pal = rng.pick(zenPalettes);
            state.colors.buildings = ColorUtils.shiftHex(pal.buildings, rng.range(-18, 18), rng.range(-10, 10), rng.range(-8, 8));
            state.colors.atmosphere = ColorUtils.shiftHex(pal.atmosphere, rng.range(-20, 20), rng.range(-10, 10), rng.range(-8, 8));
            state.colors.sky = ColorUtils.shiftHex(pal.sky, rng.range(-20, 20), rng.range(-10, 10), rng.range(-8, 8));

            // Randomize the Sun position and size across the sunset sky
            state.elements = [
              {
                id: 'el_sun',
                type: 'CIRCLE',
                enabled: true,
                color: pal.sun,
                size: rng.int(26, 48),
                x: rng.range(0.16, 0.84),
                y: rng.range(0.15, 0.44)
              }
            ];
          } else {
            // Randomize full Cairo Code palette (Buildings, Atmosphere, Sky) & geometric elements (including Sun/Circles/Rects)
            const cairoPalettes = [
              { buildings: '#e07a38', atmosphere: '#f49d52', sky: '#c8b6e2' },
              { buildings: '#be123c', atmosphere: '#fb7185', sky: '#fde68a' },
              { buildings: '#1d4ed8', atmosphere: '#38bdf8', sky: '#f472b6' },
              { buildings: '#b45309', atmosphere: '#f59e0b', sky: '#d8b4fe' },
              { buildings: '#374151', atmosphere: '#9ca3af', sky: '#e5e7eb' },
              { buildings: '#6d28d9', atmosphere: '#c084fc', sky: '#fed7aa' },
              { buildings: '#0f766e', atmosphere: '#2dd4bf', sky: '#fef08a' },
              { buildings: '#9a3412', atmosphere: '#fb923c', sky: '#bae6fd' }
            ];
            const pal = rng.pick(cairoPalettes);
            state.colors.buildings = ColorUtils.shiftHex(pal.buildings, rng.range(-22, 22), rng.range(-12, 12), rng.range(-8, 8));
            state.colors.atmosphere = ColorUtils.shiftHex(pal.atmosphere, rng.range(-22, 22), rng.range(-12, 12), rng.range(-8, 8));
            state.colors.sky = ColorUtils.shiftHex(pal.sky, rng.range(-22, 22), rng.range(-12, 12), rng.range(-8, 8));

            const shapeColors = ['#2563eb', '#10b981', '#facc15', '#ef4444', '#f97316', '#ec4899', '#06b6d4', '#eab308'];
            state.elements.forEach(el => {
              el.x = rng.range(0.14, 0.86);
              el.y = rng.range(0.14, 0.46);
              el.size = rng.int(18, 46);
              el.color = rng.pick(shapeColors);
            });
          }

          composer.rebuildAll(state);
          syncUIFromState();
        };

        onClick('updateSceneBtn', randomizeFullComposition);
        onClick('headerSeedRandomBtn', randomizeFullComposition);

        // Play / Pause & Reset Animation
        const togglePlay = () => {
          state.animation.playing = !state.animation.playing;
          syncUIFromState();
        };
        onClick('canvasPlayPauseBtn', togglePlay);
        onClick('panelPlayPauseBtn', togglePlay);

        const resetAnim = () => {
          elapsedTime = 0;
          composer.rebuildTrafficOnly(state);
        };
        onClick('canvasResetAnimBtn', resetAnim);
        onClick('panelResetAnimBtn', resetAnim);

        onChange('ctrl_livePreview', (e) => { state.animation.livePreview = e.target.checked; });
        onInput('ctrl_animSpeed', (e) => {
          state.animation.speed = parseFloat(e.target.value);
          document.getElementById('val_animSpeed').textContent = `${state.animation.speed.toFixed(1)}x`;
        });
        onChange('ctrl_motionTraffic', (e) => { state.animation.trafficMotion = e.target.checked; });
        onChange('ctrl_motionBillboards', (e) => { state.animation.billboardMotion = e.target.checked; });
        onChange('ctrl_motionCranes', (e) => { state.animation.craneMotion = e.target.checked; });
        onChange('ctrl_motionAtmosphere', (e) => { state.animation.atmosphereMotion = e.target.checked; });

        // System Config (City)
        onChange('ctrl_ratio', (e) => {
          state.sysconfig.ratio = e.target.value;
          updateCanvasAspectRatio();
          updateTelemetryCounter();
        });
        const bindCitySlider = (id, key, valId, suffix = '') => {
          onInput(id, (e) => {
            state.sysconfig[key] = Number(e.target.value);
            if (valId) document.getElementById(valId).textContent = `${state.sysconfig[key]}${suffix}`;
            composer.sceneData.buildings = BuildingGenerator.generate(state, canvas.width, canvas.height);
            composer.rebuildBillboardsOnly(state);
            composer.rebuildCranesOnly(state);
            updateTelemetryCounter();
          });
        };
        bindCitySlider('ctrl_buildingCount', 'buildingCount', 'val_buildingCount');
        bindCitySlider('ctrl_buildingHeight', 'buildingHeight', 'val_buildingHeight');
        bindCitySlider('ctrl_buildingDensity', 'buildingDensity', 'val_buildingDensity', '%');
        bindCitySlider('ctrl_heightVariation', 'heightVariation', 'val_heightVariation', '%');
        bindCitySlider('ctrl_archRandomness', 'archRandomness', 'val_archRandomness', '%');

        // Bridges Controls
        const setBridgesEnabled = (val) => {
          state.bridges.enabled = val;
          composer.rebuildBridgesAndTraffic(state);
          syncUIFromState();
        };
        onChange('ctrl_bridgesEnabled', (e) => setBridgesEnabled(e.target.checked));
        onChange('quickToggleBridges', (e) => setBridgesEnabled(e.target.checked));

        onChange('ctrl_bridgeStyle', (e) => {
          state.bridges.style = e.target.value;
          composer.rebuildBridgesAndTraffic(state);
        });
        const bindBridgeSlider = (id, key, valId, suffix = '') => {
          onInput(id, (e) => {
            state.bridges[key] = Number(e.target.value);
            if (valId) document.getElementById(valId).textContent = `${state.bridges[key]}${suffix}`;
            composer.rebuildBridgesAndTraffic(state);
            updateTelemetryCounter();
          });
        };
        bindBridgeSlider('ctrl_bridgeCount', 'count', 'val_bridgeCount');
        bindBridgeSlider('ctrl_bridgeHeight', 'height', 'val_bridgeHeight', '%');
        bindBridgeSlider('ctrl_bridgeLength', 'length', 'val_bridgeLength', '%');
        bindBridgeSlider('ctrl_bridgeCurvature', 'curvature', 'val_bridgeCurvature');
        bindBridgeSlider('ctrl_roadThickness', 'thickness', 'val_roadThickness', 'px');
        bindBridgeSlider('ctrl_supportColumns', 'columns', 'val_supportColumns');

        onChange('ctrl_bridgePlacement', (e) => {
          state.bridges.placement = e.target.value;
          composer.rebuildBridgesAndTraffic(state);
        });
        onChange('ctrl_bridgeLights', (e) => { state.bridges.lights = e.target.checked; composer.invalidateStatic(); });

        const randomizeBridges = () => {
          state.salts.bridges = Math.floor(100 + Math.random() * 9000);
          composer.rebuildBridgesAndTraffic(state);
          updateTelemetryCounter();
        };
        onClick('randBridgesBtn', randomizeBridges);
        onClick('barRandBridgesBtn', randomizeBridges);

        onClick('barRandBuildingsBtn', () => {
          state.salts.buildings = Math.floor(100 + Math.random() * 9000);
          composer.sceneData.buildings = BuildingGenerator.generate(state, canvas.width, canvas.height);
          updateTelemetryCounter();
        });

        // Traffic Controls
        const setTrafficEnabled = (val) => {
          state.traffic.enabled = val;
          composer.rebuildTrafficOnly(state);
          syncUIFromState();
        };
        onChange('ctrl_trafficEnabled', (e) => setTrafficEnabled(e.target.checked));
        onChange('quickToggleTraffic', (e) => setTrafficEnabled(e.target.checked));

        onInput('ctrl_trafficDensity', (e) => {
          state.traffic.density = Number(e.target.value);
          document.getElementById('val_trafficDensity').textContent = state.traffic.density;
          composer.rebuildTrafficOnly(state);
          updateTelemetryCounter();
        });
        onInput('ctrl_trafficSpeed', (e) => {
          state.traffic.speed = parseFloat(e.target.value);
          document.getElementById('val_trafficSpeed').textContent = `${state.traffic.speed.toFixed(1)}x`;
        });
        onInput('ctrl_vehicleSize', (e) => {
          state.traffic.size = parseFloat(e.target.value);
          document.getElementById('val_vehicleSize').textContent = `${state.traffic.size.toFixed(2)}x`;
        });
        onChange('ctrl_vehicleMix', (e) => {
          state.traffic.mix = e.target.value;
          composer.rebuildTrafficOnly(state);
        });
        onChange('ctrl_trafficDirection', (e) => {
          state.traffic.direction = e.target.value;
          composer.rebuildTrafficOnly(state);
        });
        const randomizeVehicles = () => {
          state.salts.traffic = Math.floor(100 + Math.random() * 9000);
          composer.rebuildTrafficOnly(state);
          updateTelemetryCounter();
        };
        onClick('randVehiclesBtn', randomizeVehicles);
        onClick('barRandTrafficBtn', randomizeVehicles);

        // Billboards Controls
        const setBillboardsEnabled = (val) => {
          state.billboards.enabled = val;
          composer.rebuildBillboardsOnly(state);
          syncUIFromState();
        };
        onChange('ctrl_billboardsEnabled', (e) => setBillboardsEnabled(e.target.checked));
        onChange('quickToggleBillboards', (e) => setBillboardsEnabled(e.target.checked));

        onInput('ctrl_billboardCount', (e) => {
          state.billboards.count = Number(e.target.value);
          document.getElementById('val_billboardCount').textContent = state.billboards.count;
          composer.rebuildBillboardsOnly(state);
        });
        onInput('ctrl_billboardSize', (e) => {
          state.billboards.size = parseFloat(e.target.value);
          document.getElementById('val_billboardSize').textContent = `${state.billboards.size.toFixed(2)}x`;
          composer.rebuildBillboardsOnly(state);
        });
        onChange('ctrl_billboardPlacement', (e) => {
          state.billboards.placement = e.target.value;
          composer.rebuildBillboardsOnly(state);
        });
        onInput('ctrl_billboardColor', (e) => { state.billboards.color = e.target.value; });
        onInput('ctrl_billboardAccent', (e) => { state.billboards.accent = e.target.value; });
        onChange('ctrl_billboardGraphics', (e) => {
          state.billboards.graphics = e.target.value;
          composer.rebuildBillboardsOnly(state);
        });
        onInput('ctrl_billboardText', (e) => { state.billboards.text = e.target.value; });
        onChange('ctrl_billboardLedAnim', (e) => { state.billboards.ledAnim = e.target.checked; });

        const randomizeBillboards = () => {
          state.salts.billboards = Math.floor(100 + Math.random() * 9000);
          const palette = ['#ff5500', '#e11d48', '#2563eb', '#059669', '#7c3aed', '#d97706'];
          const accents = ['#ffe600', '#00f5d4', '#ffffff', '#fde047', '#38bdf8'];
          state.billboards.color = palette[Math.floor(Math.random() * palette.length)];
          state.billboards.accent = accents[Math.floor(Math.random() * accents.length)];
          composer.rebuildBillboardsOnly(state);
          syncUIFromState();
        };
        onClick('randBillboardsBtn', randomizeBillboards);
        onClick('barRandBillboardsBtn', randomizeBillboards);

        // Cranes Controls
        const setCranesEnabled = (val) => {
          state.cranes.enabled = val;
          composer.rebuildCranesOnly(state);
          syncUIFromState();
        };
        onChange('ctrl_cranesEnabled', (e) => setCranesEnabled(e.target.checked));
        onChange('quickToggleCranes', (e) => setCranesEnabled(e.target.checked));

        onInput('ctrl_craneCount', (e) => {
          state.cranes.count = Number(e.target.value);
          document.getElementById('val_craneCount').textContent = state.cranes.count;
          composer.rebuildCranesOnly(state);
        });
        onInput('ctrl_craneHeight', (e) => {
          state.cranes.height = Number(e.target.value);
          document.getElementById('val_craneHeight').textContent = state.cranes.height;
          composer.rebuildCranesOnly(state);
        });
        onInput('ctrl_craneArmLength', (e) => {
          state.cranes.armLength = Number(e.target.value);
          document.getElementById('val_craneArmLength').textContent = state.cranes.armLength;
          composer.rebuildCranesOnly(state);
        });
        onChange('ctrl_cranePosition', (e) => {
          state.cranes.position = e.target.value;
          composer.rebuildCranesOnly(state);
        });
        onInput('ctrl_constructionDensity', (e) => {
          state.cranes.constructionDensity = Number(e.target.value);
          document.getElementById('val_constructionDensity').textContent = `${state.cranes.constructionDensity}%`;
          composer.sceneData.buildings = BuildingGenerator.generate(state, canvas.width, canvas.height);
        });
        onChange('ctrl_craneMotion', (e) => { state.cranes.motion = e.target.checked; });

        const randomizeCranes = () => {
          state.salts.cranes = Math.floor(100 + Math.random() * 9000);
          composer.rebuildCranesOnly(state);
        };
        onClick('randCranesBtn', randomizeCranes);
        onClick('barRandCranesBtn', randomizeCranes);

        // Camera Controls
        onInput('ctrl_zoom', (e) => {
          state.camera.zoom = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_zoom').textContent = `${state.camera.zoom}%`;
        });
        onInput('ctrl_pan', (e) => {
          state.camera.pan = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_pan').textContent = state.camera.pan;
        });
        onInput('ctrl_tilt', (e) => {
          state.camera.tilt = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_tilt').textContent = state.camera.tilt;
        });

        // Colors Controls
        const activatePreset = (pKey) => {
          const preset = PRESETS[pKey];
          if (!preset) return;
          state.activePresetName = preset.name;
          state.nightMode = Boolean(preset.nightMode);
          state.zenMode = Boolean(preset.zenMode);
          if (preset.animation) Object.assign(state.animation, deepClone(preset.animation));
          else state.animation.speed = 1.0;
          if (preset.elements) state.elements = deepClone(preset.elements);
          else state.elements = deepClone(DEFAULT_STATE.elements);
          if (preset.sysconfig) Object.assign(state.sysconfig, deepClone(preset.sysconfig));
          if (preset.bridges) Object.assign(state.bridges, deepClone(preset.bridges));
          if (preset.traffic) Object.assign(state.traffic, deepClone(preset.traffic));
          if (preset.billboards) Object.assign(state.billboards, deepClone(preset.billboards));
          if (preset.cranes) Object.assign(state.cranes, deepClone(preset.cranes));
          if (preset.colors) Object.assign(state.colors, deepClone(preset.colors));
          if (preset.atmosphere) Object.assign(state.atmosphere, deepClone(preset.atmosphere));
          if (preset.distortion) Object.assign(state.distortion, deepClone(preset.distortion));
          if (preset.effects) Object.assign(state.effects, deepClone(preset.effects));
          if (preset.dataviz) Object.assign(state.dataviz, deepClone(preset.dataviz));
          composer.rebuildAll(state);
          syncUIFromState();
        };

        onClick('zenModeQuickBtn', () => activatePreset('zenMode'));
        onClick('panelZenModeBtn', () => activatePreset('zenMode'));

        onChange('ctrl_colorMode', (e) => {
          if (e.target.value === 'Zen Mode') {
            activatePreset('zenMode');
            e.target.value = 'Zen Mode';
          } else {
            state.zenMode = false;
            state.colors.mode = e.target.value;
            composer.invalidateStatic();
          }
        });
        onInput('ctrl_colorBuildings', (e) => { state.colors.buildings = e.target.value; composer.invalidateStatic(); });
        onInput('ctrl_colorBuildingsVar', (e) => { state.colors.buildingsVar = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_colorAtmosphere', (e) => { state.colors.atmosphere = e.target.value; composer.invalidateStatic(); });
        onInput('ctrl_colorAtmosphereVar', (e) => { state.colors.atmosphereVar = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_colorSky', (e) => { state.colors.sky = e.target.value; composer.invalidateStatic(); });
        onInput('ctrl_colorSkyVar', (e) => { state.colors.skyVar = Number(e.target.value); composer.invalidateStatic(); });

        // Atmosphere Controls
        onInput('ctrl_fogOpacity', (e) => {
          state.atmosphere.fogOpacity = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_fogOpacity').textContent = `${state.atmosphere.fogOpacity}%`;
        });
        onInput('ctrl_fogHeight', (e) => {
          state.atmosphere.fogHeight = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_fogHeight').textContent = `${state.atmosphere.fogHeight}%`;
        });

        // Elements Add Shape
        onChange('ctrl_addShapeSelect', (e) => {
          const type = e.target.value;
          if (!type) return;
          const rng = new SeededRNG(Date.now());
          state.elements.push({
            id: `el_${Date.now()}`,
            type,
            enabled: true,
            color: rng.pick(['#3b82f6', '#10b981', '#facc15', '#ef4444', '#a855f7']),
            size: rng.int(18, 42),
            x: rng.range(0.12, 0.88),
            y: rng.range(0.12, 0.42)
          });
          e.target.value = '';
          composer.invalidateStatic();
          renderElementsListUI();
        });

        // Distortion Controls
        onInput('ctrl_xyGlitch', (e) => {
          state.distortion.xyGlitch = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_xyGlitch').textContent = state.distortion.xyGlitch;
        });
        onInput('ctrl_pixelate', (e) => {
          state.distortion.pixelate = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_pixelate').textContent = state.distortion.pixelate;
        });
        onInput('ctrl_scatter', (e) => {
          state.distortion.scatter = Number(e.target.value); composer.invalidateStatic();
          document.getElementById('val_scatter').textContent = state.distortion.scatter;
        });

        // Effects Controls
        onInput('ctrl_inkBleed', (e) => { state.effects.inkBleed = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_filmGrain', (e) => { state.effects.filmGrain = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_roughEdge', (e) => { state.effects.roughEdge = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_bloom', (e) => { state.effects.bloom = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_chromatic', (e) => { state.effects.chromatic = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_brightness', (e) => { state.effects.brightness = Number(e.target.value); });
        onInput('ctrl_contrast', (e) => { state.effects.contrast = Number(e.target.value); });
        onInput('ctrl_hue', (e) => { state.effects.hue = Number(e.target.value); });
        onInput('ctrl_saturation', (e) => { state.effects.saturation = Number(e.target.value); });
        onInput('ctrl_temperature', (e) => { state.effects.temperature = Number(e.target.value); composer.invalidateStatic(); });
        onInput('ctrl_tintEffect', (e) => { state.effects.tint = Number(e.target.value); composer.invalidateStatic(); });

        // Data Visualization Controls
        onChange('ctrl_dvEnable', (e) => { state.dataviz.enable = e.target.checked; });
        onChange('ctrl_dvApply', (e) => { state.dataviz.apply = e.target.value; });
        onInput('ctrl_dvDetection', (e) => { state.dataviz.detection = Number(e.target.value); });
        onChange('ctrl_dvOutline', (e) => { state.dataviz.outline = e.target.checked; });
        onInput('ctrl_dvOutlineColor', (e) => { state.dataviz.outlineColor = e.target.value; });
        onInput('ctrl_dvOutlineWeight', (e) => { state.dataviz.outlineWeight = parseFloat(e.target.value); });
        onChange('ctrl_dvFill', (e) => { state.dataviz.fill = e.target.checked; });
        onInput('ctrl_dvFillColor', (e) => { state.dataviz.fillColor = e.target.value; });
        onInput('ctrl_dvFillOpacity', (e) => { state.dataviz.fillOpacity = Number(e.target.value); });
        onChange('ctrl_dvText', (e) => { state.dataviz.text = e.target.checked; });
        onInput('ctrl_dvTextColor', (e) => { state.dataviz.textColor = e.target.value; });
        onInput('ctrl_dvTextSize', (e) => { state.dataviz.textSize = Number(e.target.value); });
        onChange('ctrl_dvLines', (e) => { state.dataviz.lines = e.target.checked; });
        onInput('ctrl_dvLinesColor', (e) => { state.dataviz.linesColor = e.target.value; });
        onChange('ctrl_dvConnection', (e) => { state.dataviz.connection = e.target.value; });
        onChange('ctrl_dvLineStyle', (e) => { state.dataviz.lineStyle = e.target.value; });
        onInput('ctrl_dvCurvature', (e) => { state.dataviz.curvature = Number(e.target.value); });

        // Export Controls
        onClick('quickDownloadPngBtn', () => ExportManager.exportPNG(canvas, state));
        onClick('exportPngBtn', () => ExportManager.exportPNG(canvas, state));
        onClick('quickDownloadSvgBtn', () => ExportManager.exportSVG(composer, state));
        onClick('exportSvgBtn', () => ExportManager.exportSVG(composer, state));

        onChange('ctrl_exportFormat', (e) => { state.exportConfig.format = e.target.value; });
        onChange('ctrl_exportDuration', (e) => { state.exportConfig.duration = Number(e.target.value); });
        onChange('ctrl_exportResolution', (e) => {
          state.exportConfig.resolution = e.target.value;
          updateCanvasAspectRatio();
        });
        onChange('ctrl_exportFps', (e) => { state.exportConfig.fps = Number(e.target.value); });
        onChange('ctrl_exportSpeed', (e) => {
          state.exportConfig.speed = parseFloat(e.target.value);
          state.animation.speed = state.exportConfig.speed;
          syncUIFromState();
        });

        onClick('exportRecordAnimBtn', () => {
          const overlay = document.getElementById('recordingOverlay');
          const statusTxt = document.getElementById('recordingStatusText');
          const feedback = document.getElementById('exportFeedbackMsg');
          overlay.classList.remove('hidden');
          feedback.textContent = 'Recording live canvas stream...';
          state.animation.playing = true;
          syncUIFromState();

          ExportManager.recordAnimation(
            canvas,
            state,
            (elapsed, total, fmt) => {
              statusTxt.textContent = `RECORDING ${fmt} · ${elapsed.toFixed(1)}s / ${total.toFixed(1)}s`;
            },
            (doneMsg) => {
              overlay.classList.add('hidden');
              feedback.textContent = doneMsg;
            }
          );
        });

        // Accordion Toggles & Section Reset Buttons
        document.querySelectorAll('.accordion-header').forEach(hdr => {
          hdr.addEventListener('click', (e) => {
            if (e.target.closest('.sec-reset-btn')) return;
            const targetId = hdr.getAttribute('data-target');
            const body = document.getElementById(targetId);
            const icon = hdr.querySelector('.acc-icon');
            if (body) {
              const isHidden = body.classList.toggle('hidden');
              if (icon) icon.textContent = isHidden ? '+' : '−';
            }
          });
        });

        document.querySelectorAll('.sec-reset-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const key = btn.getAttribute('data-reset');
            if (key === 'animation') state.animation = deepClone(DEFAULT_STATE.animation);
            else if (key === 'sysconfig') state.sysconfig = deepClone(DEFAULT_STATE.sysconfig);
            else if (key === 'bridges') state.bridges = deepClone(DEFAULT_STATE.bridges);
            else if (key === 'traffic') state.traffic = deepClone(DEFAULT_STATE.traffic);
            else if (key === 'billboards') state.billboards = deepClone(DEFAULT_STATE.billboards);
            else if (key === 'cranes') state.cranes = deepClone(DEFAULT_STATE.cranes);
            else if (key === 'camera') state.camera = deepClone(DEFAULT_STATE.camera);
            else if (key === 'colors') state.colors = deepClone(DEFAULT_STATE.colors);
            else if (key === 'atmosphere') state.atmosphere = deepClone(DEFAULT_STATE.atmosphere);
            else if (key === 'elements') state.elements = deepClone(DEFAULT_STATE.elements);
            else if (key === 'distortion') state.distortion = deepClone(DEFAULT_STATE.distortion);
            else if (key === 'effects') state.effects = deepClone(DEFAULT_STATE.effects);
            else if (key === 'dataviz') state.dataviz = deepClone(DEFAULT_STATE.dataviz);
            else if (key === 'export') state.exportConfig = deepClone(DEFAULT_STATE.exportConfig);

            composer.rebuildAll(state);
            syncUIFromState();
          });
        });

        // Category Filter Tabs
        document.querySelectorAll('.panel-filter-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const filter = btn.getAttribute('data-filter');
            document.querySelectorAll('.panel-filter-btn').forEach(b => {
              b.classList.remove('bg-blue-600', 'text-white', 'font-semibold');
              b.classList.add('bg-[#171a22]');
            });
            btn.classList.add('bg-blue-600', 'text-white', 'font-semibold');

            document.querySelectorAll('.ctrl-section').forEach(sec => {
              const cat = sec.getAttribute('data-category');
              if (filter === 'all' || cat === filter) {
                sec.classList.remove('hidden');
              } else {
                sec.classList.add('hidden');
              }
            });
          });
        });

        // Expand / Collapse All Sections
        let allExpanded = true;
        onClick('expandCollapseAllBtn', () => {
          allExpanded = !allExpanded;
          document.querySelectorAll('.ctrl-section').forEach(sec => {
            const body = sec.querySelector('.accordion-body');
            const icon = sec.querySelector('.acc-icon');
            if (body) {
              body.classList.toggle('hidden', !allExpanded);
              if (icon) icon.textContent = allExpanded ? '−' : '+';
            }
          });
        });

        // Presets Dropdown & Selection
        const presetsMenu = document.getElementById('presetsMenu');
        onClick('presetsDropdownBtn', (e) => {
          e.stopPropagation();
          presetsMenu.classList.toggle('hidden');
        });
        document.addEventListener('click', (e) => {
          if (!e.target.closest('#presetsMenu') && !e.target.closest('#presetsDropdownBtn')) {
            presetsMenu.classList.add('hidden');
          }
        });

        document.querySelectorAll('.preset-item-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const pKey = btn.getAttribute('data-preset');
            const preset = PRESETS[pKey];
            if (!preset) return;
            state.activePresetName = preset.name;
            state.nightMode = Boolean(preset.nightMode);
            state.zenMode = Boolean(preset.zenMode);
            if (preset.animation) Object.assign(state.animation, deepClone(preset.animation));
            else state.animation.speed = 1.0;
            if (preset.elements) state.elements = deepClone(preset.elements);
            else state.elements = deepClone(DEFAULT_STATE.elements);
            if (preset.sysconfig) Object.assign(state.sysconfig, deepClone(preset.sysconfig));
            if (preset.bridges) Object.assign(state.bridges, deepClone(preset.bridges));
            if (preset.traffic) Object.assign(state.traffic, deepClone(preset.traffic));
            if (preset.billboards) Object.assign(state.billboards, deepClone(preset.billboards));
            if (preset.cranes) Object.assign(state.cranes, deepClone(preset.cranes));
            if (preset.colors) Object.assign(state.colors, deepClone(preset.colors));
            if (preset.atmosphere) Object.assign(state.atmosphere, deepClone(preset.atmosphere));
            if (preset.distortion) Object.assign(state.distortion, deepClone(preset.distortion));
            if (preset.effects) Object.assign(state.effects, deepClone(preset.effects));
            if (preset.dataviz) Object.assign(state.dataviz, deepClone(preset.dataviz));

            composer.rebuildAll(state);
            syncUIFromState();
            presetsMenu.classList.add('hidden');
          });
        });

        // Save / Load Custom Presets
        const savedPresets = [];
        function renderSavedPresets() {
          const listEl = document.getElementById('savedPresetsList');
          if (!listEl) return;
          if (!savedPresets.length) {
            listEl.innerHTML = `<div class="italic text-gray-500">None saved yet</div>`;
            return;
          }
          listEl.innerHTML = '';
          savedPresets.forEach((sp, i) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'w-full text-left px-2 py-1 rounded bg-[#1b202e] hover:bg-blue-600/30 text-blue-200 flex items-center justify-between';
            btn.innerHTML = `<span>${sp.name}</span><span class="text-[9px] text-gray-400">#${sp.data.seed}</span>`;
            btn.addEventListener('click', () => {
              Object.assign(state, deepClone(sp.data));
              composer.rebuildAll(state);
              syncUIFromState();
              presetsMenu.classList.add('hidden');
            });
            listEl.appendChild(btn);
          });
        }

        onClick('savePresetBtn', () => {
          const nameInput = document.getElementById('savePresetNameInput');
          const name = (nameInput.value || '').trim() || `Cairo Custom ${savedPresets.length + 1}`;
          state.activePresetName = name;
          savedPresets.push({ name, data: deepClone(state) });
          nameInput.value = '';
          renderSavedPresets();
          syncUIFromState();
        });

        onClick('copyPresetCodeBtn', () => {
          const code = btoa(unescape(encodeURIComponent(JSON.stringify(state))));
          const input = document.getElementById('loadPresetCodeInput');
          input.value = code;
          input.select();
          try {
            document.execCommand('copy');
          } catch (e) {}
        });

        onClick('loadPresetCodeBtn', () => {
          const input = document.getElementById('loadPresetCodeInput');
          const raw = (input.value || '').trim();
          if (!raw) return;
          try {
            const parsed = JSON.parse(decodeURIComponent(escape(atob(raw))));
            Object.assign(state, parsed);
            composer.rebuildAll(state);
            syncUIFromState();
            presetsMenu.classList.add('hidden');
          } catch (e) {
            input.value = 'INVALID CODE';
          }
        });

        // Navigation Info Modal (BOOK / STORE / ABOUT)
        const infoModal = document.getElementById('infoModal');
        const infoTitle = document.getElementById('infoModalTitle');
        const infoContent = document.getElementById('infoModalContent');

        const navDescriptions = {
          book: {
            title: 'CAIRO CODE — THE ART BOOK',
            html: `<p><strong>Cairo Code</strong> began as a 122-page experimental art book created by director and visual designer <strong>Ahmed Arafa</strong> (<a href="https://cairo-code.com/book" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline">cairo-code.com/book</a>), printed on recycled paper and containing around 150 artworks.</p>
                   <p class="text-gray-400 italic border-l-2 border-amber-500 pl-3">"For months, stuck in heavy traffic, I did nothing but look. I categorized the skyline's debris: windows, balconies, doors, pillars, satellite..."</p>`
          },
          store: {
            title: 'CAIRO CODE — ARCHIVE & STORE',
            html: `<p>The original <strong>Cairo Code Store</strong> (<a href="https://cairo-code.com/store" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline">cairo-code.com/store</a>) showcases physical editions and prints built from photography and digital design documenting Cairo's dense urban skyline.</p>`
          },
          about: {
            title: 'ABOUT CAIRO CODE & ANIMATED EXPANSION',
            html: `<p><strong>Original Concept:</strong> Created by Ahmed Arafa (<a href="https://cairo-code.com/about" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline">cairo-code.com/about</a>), encoding Cairo's architectural density into a generative JavaScript skyline tool (<a href="https://cairo-code.com/app" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline">cairo-code.com/app</a>).</p>
                   <p><strong>Animated City Expansion:</strong> This standalone prototype preserves the original visual identity, 8 control panels, color modes, geometric overlays, glitch/post effects, and computer-vision Data Visualization while expanding the city into a living, continuously animated Cairo environment with procedural elevated concrete bridges, 5 authentic Egyptian vehicle types, rooftop/highway LED billboards, and animated construction cranes.</p>`
          }
        };

        document.querySelectorAll('.nav-tab-btn').forEach(btn => {
          btn.addEventListener('click', () => {
            const tab = btn.getAttribute('data-nav');
            if (tab === 'app') {
              infoModal.classList.add('hidden');
              return;
            }
            const info = navDescriptions[tab];
            if (info) {
              infoTitle.textContent = info.title;
              infoContent.innerHTML = info.html;
              infoModal.classList.remove('hidden');
            }
          });
        });

        onClick('closeInfoModalBtn', () => infoModal.classList.add('hidden'));
        onClick('infoModalBackBtn', () => infoModal.classList.add('hidden'));

        // Keyboard Shortcut: Spacebar toggles Play/Pause (when not typing in an input)
        window.addEventListener('keydown', (e) => {
          const tag = (e.target && e.target.tagName) || '';
          if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
          if (e.code === 'Space') {
            e.preventDefault();
            togglePlay();
          }
        });
      }

      // -------------------------------------------------------------------
      // 11. REAL-TIME 60 FPS RENDERING LOOP (Delta-Time Driven)
      // -------------------------------------------------------------------
      let lastFrameTime = performance.now();
      let elapsedTime = 0;
      let frameCounter = 0;
      let fpsAccumTime = 0;

      function animateLoop(now) {
        const dt = Math.min(0.1, (now - lastFrameTime) / 1000);
        lastFrameTime = now;

        frameCounter++;
        fpsAccumTime += dt;
        if (fpsAccumTime >= 0.5) {
          const fps = Math.min(60, Math.round(frameCounter / fpsAccumTime));
          const fpsEl = document.getElementById('fpsCounter');
          if (fpsEl) fpsEl.textContent = `${fps} FPS`;
          frameCounter = 0;
          fpsAccumTime = 0;
        }

        if (state.animation.playing) {
          elapsedTime += dt;
          VehicleGenerator.update(composer.sceneData.vehicles, dt, state);
        }

        if (state.animation.livePreview || state.animation.playing) {
          composer.render(state, elapsedTime);
        }

        requestAnimationFrame(animateLoop);
      }

      // Boot application
      updateCanvasAspectRatio();
      bindControls();
      syncUIFromState();
      composer.render(state, 0);
      requestAnimationFrame(animateLoop);
    })();
