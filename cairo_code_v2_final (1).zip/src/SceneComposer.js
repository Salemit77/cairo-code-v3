// 8. SYSTEM 6: SCENE COMPOSER & AUTHENTIC CAIRO CODE DISTORTION ENGINE (Single-Blit 60 FPS)
      // -------------------------------------------------------------------
      class SceneComposer {
        constructor(canvas) {
          this.canvas = canvas;
          this.ctx = canvas.getContext('2d', { alpha: false });
          this.sceneData = {
            buildings: [],
            bridges: [],
            vehicles: [],
            billboards: [],
            cranes: []
          };
          this.detectedNodes = [];
          this.staticBldNodes = [];

          // Single unified static scene buffer (pre-bakes Sky, Buildings, Bridges, Scatter, XY Glitch, Ink Bleed, Rough Edge, Grain)
          // so the 60 FPS animation loop only performs ONE fast drawImage blit per frame!
          this.staticDirty = true;
          this.staticSceneCanvas = document.createElement('canvas');
          this.workCanvas = document.createElement('canvas');
          this.bloomCanvas = document.createElement('canvas');
          this.bloomCanvas.width = 160;
          this.bloomCanvas.height = 90;

          // Pre-rendered colorful + monochrome film grain tile (256x256) matching original Cairo Code grain
          this.grainCanvas = document.createElement('canvas');
          this.grainCanvas.width = 256;
          this.grainCanvas.height = 256;
          const gCtx = this.grainCanvas.getContext('2d');
          const imgData = gCtx.createImageData(256, 256);
          const data = imgData.data;
          const gRng = new SeededRNG(1337);
          for (let i = 0; i < data.length; i += 4) {
            const isColorSpeck = gRng.next() < 0.35;
            if (isColorSpeck) {
              data[i] = gRng.int(40, 255);
              data[i + 1] = gRng.int(30, 230);
              data[i + 2] = gRng.int(60, 255);
            } else {
              const v = gRng.next() > 0.5 ? 245 : 15;
              data[i] = v;
              data[i + 1] = v;
              data[i + 2] = v;
            }
            data[i + 3] = gRng.int(35, 165);
          }
          gCtx.putImageData(imgData, 0, 0);
          this.grainPattern = this.ctx.createPattern(this.grainCanvas, 'repeat');
        }

        invalidateStatic() {
          this.staticDirty = true;
        }

        rebuildAll(state) {
          const w = this.canvas.width;
          const h = this.canvas.height;
          this.sceneData.buildings = BuildingGenerator.generate(state, w, h);
          this.sceneData.bridges = BridgeGenerator.generate(state, w, h);
          this.sceneData.vehicles = VehicleGenerator.generate(state, this.sceneData.bridges);
          this.sceneData.billboards = BillboardGenerator.generate(state, this.sceneData.buildings, this.sceneData.bridges, w, h);
          this.sceneData.cranes = CraneGenerator.generate(state, this.sceneData.buildings, w, h);
          this.staticDirty = true;
        }

        rebuildBridgesAndTraffic(state) {
          const w = this.canvas.width;
          const h = this.canvas.height;
          this.sceneData.bridges = BridgeGenerator.generate(state, w, h);
          this.sceneData.vehicles = VehicleGenerator.generate(state, this.sceneData.bridges);
          this.sceneData.billboards = BillboardGenerator.generate(state, this.sceneData.buildings, this.sceneData.bridges, w, h);
          this.staticDirty = true;
        }

        rebuildTrafficOnly(state) {
          this.sceneData.vehicles = VehicleGenerator.generate(state, this.sceneData.bridges);
          this.cacheDynamicColors(state);
        }

        rebuildBillboardsOnly(state) {
          const w = this.canvas.width;
          const h = this.canvas.height;
          this.sceneData.billboards = BillboardGenerator.generate(state, this.sceneData.buildings, this.sceneData.bridges, w, h);
          this.cacheDynamicColors(state);
        }

        rebuildCranesOnly(state) {
          const w = this.canvas.width;
          const h = this.canvas.height;
          this.sceneData.cranes = CraneGenerator.generate(state, this.sceneData.buildings, w, h);
          this.cacheDynamicColors(state);
        }

        resolveColor(baseHex, hueShift, lightShift, state, depthLayer = 1, toneType = 1) {
          const mode = state.colors.mode;
          let targetHex = baseHex;
          if (!state.zenMode && !state.nightMode) {
            if (toneType === 0) targetHex = ColorUtils.shiftHex(baseHex, 16, 12, 10); // Golden-Yellow
            else if (toneType === 2) targetHex = ColorUtils.shiftHex(baseHex, -12, 10, -6); // Coral/Terracotta
            else if (toneType === 3) targetHex = '#102428'; // Deep Dark Slate/Green-Black contrast block
          }
          const atmMix = depthLayer === 0 ? 0.46 : (depthLayer === 1 ? 0.18 : 0.04);
          let rawHex;
          if (mode === 'Flat') {
            rawHex = ColorUtils.shiftHex(targetHex, hueShift * 0.25, -14, lightShift * 0.35 + 8);
          } else if (mode === 'Tint') {
            rawHex = ColorUtils.shiftHex(targetHex, hueShift * 0.18, 12, lightShift * 0.65);
          } else {
            rawHex = ColorUtils.shiftHex(targetHex, hueShift * 0.45, -4, lightShift * 0.5);
          }
          return ColorUtils.mixHex(rawHex, state.colors.atmosphere, atmMix);
        }

        applyLayerCamera(ctx, w, h, depthLayer, state) {
          const parallax = depthLayer === 0 ? 0.45 : (depthLayer === 1 ? 0.8 : 1.15);
          const zoomScale = (state.camera.zoom / 100);
          const panX = state.camera.pan * 2.2 * parallax;
          const tiltY = state.camera.tilt * 1.6 * parallax;

          ctx.save();
          ctx.translate(w * 0.5 + panX, h * 0.65 + tiltY);
          ctx.scale(zoomScale, zoomScale);
          ctx.translate(-w * 0.5, -h * 0.65);
        }

        cacheDynamicColors(state) {
          this.sceneData.cranes.forEach(c => {
            c.cachedColor = this.resolveColor(state.colors.buildings, -4, -18, state, c.depthLayer, 3);
          });
          this.sceneData.billboards.forEach(bb => {
            bb.cachedStructColor = this.resolveColor(state.colors.buildings, 0, -24, state, bb.depthLayer, 3);
            bb.cachedPlaneColor = this.resolveColor(state.colors.buildings, bb.labelIndex * 6 - 8, -6, state, bb.depthLayer, bb.labelIndex % 4);
            bb.cachedPulseColor = ColorUtils.mixHex(bb.cachedPlaneColor, state.colors.atmosphere, 0.35);
          });
          this.sceneData.vehicles.forEach(v => {
            v.cachedBlockColor = this.resolveColor(state.colors.buildings, v.bodyTint * 0.6, -20, state, v.depthLayer, 3);
          });
        }

        rebuildStaticCaches(state) {
          const w = this.canvas.width;
          const h = this.canvas.height;

          if (this.staticSceneCanvas.width !== w || this.staticSceneCanvas.height !== h) {
            this.staticSceneCanvas.width = w;
            this.staticSceneCanvas.height = h;
            this.workCanvas.width = w;
            this.workCanvas.height = h;
          }

          this.staticBldNodes = [];
          const sCtx = this.staticSceneCanvas.getContext('2d');
          sCtx.clearRect(0, 0, w, h);

          // 1. SKY GRADIENT (Soft lavender/periwinkle to light pinkish-orange horizon like Cairo Code)
          const skyTop = state.nightMode
            ? ColorUtils.shiftHex(state.colors.sky, -8, -10, -25)
            : (state.zenMode ? ColorUtils.shiftHex(state.colors.sky, -35, 15, -32) : ColorUtils.shiftHex(state.colors.sky, -12, 8, -6));
          const skyMid = state.colors.sky;
          const skyHorizon = ColorUtils.mixHex(state.colors.sky, state.colors.atmosphere, 0.68);

          const skyGrad = sCtx.createLinearGradient(0, 0, 0, h);
          skyGrad.addColorStop(0, skyTop);
          skyGrad.addColorStop(0.54, skyMid);
          skyGrad.addColorStop(1, skyHorizon);
          sCtx.fillStyle = skyGrad;
          sCtx.fillRect(0, 0, w, h);

          if (state.zenMode) {
            const sunEl = state.elements.find(el => el.enabled && el.type === 'CIRCLE') || { x: 0.5, y: 0.34, size: 36 };
            const sx = sunEl.x * w;
            const sy = sunEl.y * h;
            const sr = (sunEl.size / 100) * Math.min(w, h) * 0.45;
            const halo = sCtx.createRadialGradient(sx, sy, sr * 0.6, sx, sy, sr * 3.2);
            halo.addColorStop(0, 'rgba(254, 240, 138, 0.42)');
            halo.addColorStop(0.5, 'rgba(251, 146, 60, 0.16)');
            halo.addColorStop(1, 'rgba(251, 146, 60, 0)');
            sCtx.fillStyle = halo;
            sCtx.fillRect(0, 0, w, h);
          }

          // 2. DEPTH LAYERS 0, 1, 2 BUILDINGS & BRIDGES
          this.applyLayerCamera(sCtx, w, h, 0, state);
          this.sceneData.buildings.filter(b => b.depthLayer === 0).forEach(bld => this.drawBuilding(sCtx, bld, state));
          this.sceneData.bridges.filter(br => br.depthLayer === 0).forEach(br => this.drawBridge(sCtx, br, state));
          sCtx.restore();

          this.drawFogBand(sCtx, state, w, h, 0.45);

          this.applyLayerCamera(sCtx, w, h, 1, state);
          this.sceneData.buildings.filter(b => b.depthLayer === 1).forEach(bld => this.drawBuilding(sCtx, bld, state));
          this.sceneData.bridges.filter(br => br.depthLayer === 1).forEach(br => this.drawBridge(sCtx, br, state));
          sCtx.restore();

          this.applyLayerCamera(sCtx, w, h, 2, state);
          this.sceneData.buildings.filter(b => b.depthLayer === 2).forEach(bld => this.drawBuilding(sCtx, bld, state));
          this.sceneData.bridges.filter(br => br.depthLayer === 2).forEach(br => this.drawBridge(sCtx, br, state));
          sCtx.restore();

          this.drawFogBand(sCtx, state, w, h, 0.9);

          // 3. AUTHENTIC CAIRO CODE "SCATTER" (Displaces medium rectangular building chunks into neighboring areas & middle sky BEFORE upper-right circles!)
          this.applyAuthenticScatter(sCtx, state, w, h);

          // 4. ORIGINAL CAIRO CODE GEOMETRIC ELEMENTS (Upper-right yellow/pink/lime circles & left blue rectangle)
          this.drawOriginalElements(sCtx, state, w, h);

          // 5. AUTHENTIC CAIRO CODE "XY GLITCH" & "PIXELATE"
          this.applyAuthenticGlitchAndPixelate(sCtx, state, w, h);

          // 6. AUTHENTIC CAIRO CODE "INK BLEED", "ROUGH EDGE", "CHROMATIC ABERRATION" & "FILM GRAIN"
          this.applyStaticPostEffects(sCtx, state, w, h);

          this.cacheDynamicColors(state);
          this.staticDirty = false;
        }

        // Authentic Scatter: Copies & displaces medium-sized rectangular building chunks across the skyline and middle sky
        applyAuthenticScatter(ctx, state, w, h) {
          const scatter = state.distortion.scatter;
          if (scatter <= 0) return;
          const rng = new SeededRNG(state.seed ^ 0x5CA77E);
          const chunkCount = Math.floor((scatter / 100) * 68);

          for (let i = 0; i < chunkCount; i++) {
            const cw = rng.range(14, 62);
            const ch = rng.range(10, 48);
            // Sample from building zone (lower 70% of canvas)
            const sx = rng.range(20, Math.max(40, w - cw - 20));
            const sy = rng.range(h * 0.32, Math.max(h * 0.35, h - ch - 10));
            // Displace into neighboring areas and middle sky
            const spreadX = (scatter / 100) * 160;
            const spreadY = (scatter / 100) * 190;
            const dx = Math.max(0, Math.min(w - cw, sx + rng.range(-spreadX, spreadX)));
            const dy = Math.max(h * 0.14, Math.min(h - ch, sy + rng.range(-spreadY, spreadY * 0.45)));
            ctx.drawImage(this.staticSceneCanvas, sx, sy, cw, ch, dx, dy, cw, ch);
          }
        }

        // Authentic XY Glitch (Both Horizontal AND Vertical slice displacements) + Uniform Mosaic Pixelate
        applyAuthenticGlitchAndPixelate(ctx, state, w, h) {
          const { xyGlitch, pixelate } = state.distortion;
          const rng = new SeededRNG(state.seed ^ 0x9117C4);

          if (xyGlitch > 0) {
            const hSlices = Math.floor((xyGlitch / 100) * 42);
            for (let s = 0; s < hSlices; s++) {
              const sy = rng.range(0, h - 18);
              const sh = rng.range(2, 16);
              const shiftX = rng.range(-xyGlitch * 0.48, xyGlitch * 0.48);
              ctx.drawImage(this.staticSceneCanvas, 0, sy, w, sh, shiftX, sy, w, sh);
            }
            const vSlices = Math.floor((xyGlitch / 100) * 28);
            for (let v = 0; v < vSlices; v++) {
              const sx = rng.range(0, w - 18);
              const sw = rng.range(2, 14);
              const shiftY = rng.range(-xyGlitch * 0.32, xyGlitch * 0.32);
              ctx.drawImage(this.staticSceneCanvas, sx, 0, sw, h, sx, shiftY, sw, h);
            }
          }

          if (pixelate > 1) {
            const blockSize = Math.max(2, Math.floor((pixelate / 100) * 28));
            const sw = Math.max(12, Math.floor(w / blockSize));
            const sh = Math.max(12, Math.floor(h / blockSize));
            const wCtx = this.workCanvas.getContext('2d');
            wCtx.imageSmoothingEnabled = false;
            wCtx.clearRect(0, 0, sw, sh);
            wCtx.drawImage(this.staticSceneCanvas, 0, 0, w, h, 0, 0, sw, sh);
            ctx.save();
            ctx.imageSmoothingEnabled = false;
            ctx.drawImage(this.workCanvas, 0, 0, sw, sh, 0, 0, w, h);
            ctx.restore();
          }
        }

        // Authentic Ink Bleed, Rough Edge, Chromatic Aberration & Film Grain (Baked into static cache for 0ms per-frame cost!)
        applyStaticPostEffects(ctx, state, w, h) {
          const fx = state.effects;
          const rng = new SeededRNG(state.seed ^ 0xEFFEC7);

          // 1. INK BLEED: Multi-pass directional radial ink spread + darkening multiply halo
          if (fx.inkBleed > 0) {
            const bleedDist = (fx.inkBleed / 100) * 5.5;
            ctx.save();
            ctx.globalCompositeOperation = 'multiply';
            ctx.globalAlpha = Math.min(0.48, (fx.inkBleed / 100) * 0.45);
            ctx.drawImage(this.staticSceneCanvas, -bleedDist, 0);
            ctx.drawImage(this.staticSceneCanvas, bleedDist, 0);
            ctx.drawImage(this.staticSceneCanvas, 0, bleedDist * 0.8);
            ctx.restore();
          }

          // 2. ROUGH EDGE: High-frequency organic micro-jitter along horizontal & vertical edges (torn paper / screenprint texture)
          if (fx.roughEdge > 0) {
            const amp = (fx.roughEdge / 100) * 4.5;
            const step = 3;
            for (let y = 0; y < h; y += step) {
              if (rng.next() < 0.65) {
                const jx = (rng.next() - 0.5) * 2 * amp;
                ctx.drawImage(this.staticSceneCanvas, 0, y, w, step, jx, y, w, step);
              }
            }
            for (let x = 0; x < w; x += step * 2) {
              if (rng.next() < 0.45) {
                const jy = (rng.next() - 0.5) * 2 * amp;
                ctx.drawImage(this.staticSceneCanvas, x, 0, step, h, x, jy, step, h);
              }
            }
          }

          // 3. CHROMATIC ABERRATION: Subtle RGB fringing
          if (fx.chromatic > 0) {
            const shift = (fx.chromatic / 100) * 5.5;
            ctx.save();
            ctx.globalCompositeOperation = 'screen';
            ctx.globalAlpha = Math.min(0.28, (fx.chromatic / 100) * 0.32);
            ctx.drawImage(this.staticSceneCanvas, -shift, 0);
            ctx.drawImage(this.staticSceneCanvas, shift, 0);
            ctx.restore();
          }

          // 4. BLOOM
          if (fx.bloom > 0) {
            const bCtx = this.bloomCanvas.getContext('2d');
            bCtx.drawImage(this.staticSceneCanvas, 0, 0, this.bloomCanvas.width, this.bloomCanvas.height);
            ctx.save();
            ctx.globalCompositeOperation = 'screen';
            ctx.globalAlpha = (fx.bloom / 100) * 0.35;
            ctx.drawImage(this.bloomCanvas, 0, 0, w, h);
            ctx.restore();
          }

          // 5. TEMPERATURE & TINT
          if (fx.temperature !== 0 || fx.tint !== 0) {
            ctx.save();
            if (fx.temperature !== 0) {
              const warmHex = fx.temperature > 0 ? '#f97316' : '#38bdf8';
              ctx.fillStyle = ColorUtils.rgba(warmHex, Math.abs(fx.temperature) / 350);
              ctx.fillRect(0, 0, w, h);
            }
            if (fx.tint !== 0) {
              const tintHex = fx.tint > 0 ? '#ec4899' : '#10b981';
              ctx.fillStyle = ColorUtils.rgba(tintHex, Math.abs(fx.tint) / 350);
              ctx.fillRect(0, 0, w, h);
            }
            ctx.restore();
          }

          // 6. FILM GRAIN: Fine colorful/monochrome texture baked once into the static canvas
          if (fx.filmGrain > 0 && this.grainPattern) {
            ctx.save();
            ctx.globalAlpha = Math.min(0.36, (fx.filmGrain / 100) * 0.34);
            ctx.fillStyle = this.grainPattern;
            ctx.fillRect(0, 0, w, h);
            ctx.restore();
          }
        }

        // ULTRA-LIGHTWEIGHT 60 FPS RENDER LOOP (1 Single Static Blit + Dynamic Entities + Data Visualization)
        render(state, elapsedTime) {
          const ctx = this.ctx;
          const w = this.canvas.width;
          const h = this.canvas.height;

          const fx = state.effects;
          const cssFilter = (fx.brightness !== 0 || fx.contrast !== 0 || fx.hue !== 0 || fx.saturation !== 0)
            ? `brightness(${100 + fx.brightness}%) contrast(${100 + fx.contrast}%) hue-rotate(${fx.hue}deg) saturate(${100 + fx.saturation}%)`
            : 'none';
          if (this.canvas.style.filter !== cssFilter) {
            this.canvas.style.filter = cssFilter;
          }

          if (this.staticDirty) {
            this.rebuildStaticCaches(state);
          }

          this.detectedNodes = this.staticBldNodes.slice();

          // 1. SINGLE HARDWARE BLIT OF THE ENTIRE DISTORTED STATIC SCENE (< 0.2ms!)
          ctx.drawImage(this.staticSceneCanvas, 0, 0);

          // 2. DYNAMIC ANIMATED ENTITIES (Cranes, Traffic, Billboards)
          for (let layer = 0; layer <= 2; layer++) {
            this.applyLayerCamera(ctx, w, h, layer, state);
            if (layer <= 1) {
              this.sceneData.cranes.filter(c => c.depthLayer === layer).forEach(crane => this.drawCrane(ctx, crane, state, elapsedTime));
            }
            if (layer >= 1) {
              this.sceneData.billboards.filter(bb => bb.depthLayer === layer).forEach(bb => this.drawBillboard(ctx, bb, state, elapsedTime));
            }
            this.sceneData.vehicles.filter(v => v.depthLayer === layer).forEach(v => this.drawVehicle(ctx, v, state));
            ctx.restore();
          }

          // 3. DATA VISUALIZATION OVERLAY (Sharp pink/blue bounding boxes & curved connection lines on top)
          if (state.dataviz.enable) {
            this.drawDataVisualization(ctx, state, elapsedTime);
          }
        }

        drawOriginalElements(ctx, state, w, h) {
          state.elements.forEach((el) => {
            if (!el.enabled) return;
            ctx.save();
            ctx.fillStyle = el.color;
            const r = (el.size / 100) * Math.min(w, h) * 0.45;
            const cx = el.x * w;
            const cy = el.y * h;
            if (el.type === 'CIRCLE') {
              ctx.beginPath();
              ctx.arc(cx, cy, r, 0, Math.PI * 2);
              ctx.fill();
            } else {
              ctx.fillRect(cx - r * 0.85, cy - r * 1.15, r * 1.7, r * 2.3);
              // Inner dark architectural detail edge like original Cairo Code blue block
              ctx.fillStyle = '#0d1f22';
              ctx.fillRect(cx + r * 0.55, cy - r * 1.15, r * 0.3, r * 2.3);
            }
            ctx.restore();
          });
        }

        drawFogBand(ctx, state, w, h, intensityMult) {
          const opacity = (state.atmosphere.fogOpacity / 100) * 0.68 * intensityMult;
          if (opacity <= 0.01) return;
          const fogH = Math.max(0.15, state.atmosphere.fogHeight / 100) * h;
          const grad = ctx.createLinearGradient(0, h - fogH, 0, h);
          grad.addColorStop(0, ColorUtils.rgba(state.colors.atmosphere, 0));
          grad.addColorStop(0.55, ColorUtils.rgba(state.colors.atmosphere, opacity * 0.65));
          grad.addColorStop(1, ColorUtils.rgba(state.colors.atmosphere, opacity));
          ctx.fillStyle = grad;
          ctx.fillRect(0, h - fogH, w, fogH);
        }

        drawBuilding(ctx, bld, state) {
          const fillHex = this.resolveColor(state.colors.buildings, bld.hueShift, bld.lightShift, state, bld.depthLayer, bld.toneType);
          const scafHex = ColorUtils.shiftHex(fillHex, -4, 4, -18);
          const scafAccentHex = '#102428';

          ctx.fillStyle = fillHex;
          ctx.fillRect(bld.x, bld.y, bld.w, bld.h);

          // Bold Interior Geometric Architectural Sub-Blocks (Authentic Cairo Code collage blocks)
          if (bld.subBlocks && bld.subBlocks.length) {
            bld.subBlocks.forEach(sb => {
              const bx = bld.x + sb.rx * bld.w;
              const by = bld.y + sb.ry * bld.h;
              const bw = sb.rw * bld.w;
              const bh = sb.rh * bld.h;
              if (sb.style === 'blueFeature' && !state.zenMode) {
                ctx.fillStyle = '#1d4ed8';
                ctx.fillRect(bx, by, bw, bh);
                ctx.fillStyle = '#0d1f22';
                ctx.fillRect(bx + bw * 0.78, by, bw * 0.22, bh);
              } else if (sb.style === 'darkCutout') {
                ctx.fillStyle = '#102428';
                ctx.fillRect(bx, by, bw, bh);
              } else {
                ctx.fillStyle = ColorUtils.shiftHex(fillHex, 14, 10, -16);
                ctx.fillRect(bx, by, bw, bh);
              }
            });
          }

          // Creative Geometric Construction Scaffolding & Outrigger Counterweights
          if (bld.isUnfinished && bld.scaffold) {
            const sc = bld.scaffold;
            const totalW = bld.w + sc.sideOverhang * 2;
            const startX = bld.x - sc.sideOverhang;
            const startY = bld.y - sc.topRise;
            const colW = totalW / sc.cols;
            const rowH = sc.cellH;

            ctx.save();
            ctx.strokeStyle = scafHex;
            ctx.fillStyle = scafHex;
            ctx.lineWidth = bld.depthLayer === 0 ? 1.6 : 2.3;

            sc.cells.forEach(cell => {
              if (!cell.active) return;
              const cx = startX + cell.c * colW;
              const cy = startY + cell.r * rowH;
              ctx.strokeRect(cx, cy, colW, rowH);
              if (cell.hasXBrace) {
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx + colW, cy + rowH);
                ctx.moveTo(cx + colW, cy);
                ctx.lineTo(cx, cy + rowH);
                ctx.stroke();
              }
              if (cell.hasPlankSlab) {
                ctx.fillStyle = scafAccentHex;
                ctx.fillRect(cx - 2, cy + rowH - 3.5, colW + 4, 3.5);
              }
              if (cell.hasSideBlock) {
                const bx = cell.c === 0 ? cx - 9 : cx + colW + 2;
                ctx.fillStyle = scafAccentHex;
                ctx.fillRect(bx, cy + 2, 7, rowH - 4);
              }
            });

            const outDir = sc.sideMount;
            const anchorX = outDir < 0 ? startX : startX + totalW;
            const tipX = anchorX + outDir * sc.outRiggerLen;
            const beamY = startY + rowH;

            ctx.lineWidth = bld.depthLayer === 0 ? 2.2 : 3.2;
            ctx.beginPath();
            ctx.moveTo(anchorX - outDir * 14, beamY);
            ctx.lineTo(tipX, beamY);
            ctx.moveTo(anchorX, beamY + rowH * 1.4);
            ctx.lineTo(tipX - outDir * 3, beamY);
            ctx.stroke();

            ctx.lineWidth = 1.6;
            ctx.beginPath();
            ctx.moveTo(tipX - outDir * 2, beamY);
            ctx.lineTo(tipX - outDir * 2, beamY + 26);
            ctx.stroke();

            ctx.fillStyle = scafAccentHex;
            const bw = 10;
            const bh = sc.counterBlockH;
            ctx.fillRect(tipX - outDir * 2 - bw * 0.5, beamY + 26, bw, bh);
            ctx.fillRect(tipX - outDir * 2 - bw * 0.7, beamY + 26 + bh + 2, bw * 1.4, bh * 0.55);
            ctx.restore();
          }

          ctx.fillStyle = fillHex;
          bld.rooftopItems.forEach(item => {
            const ix = bld.x + item.rx * bld.w;
            if (item.type === 'rebar') {
              ctx.fillRect(ix, bld.y - item.h * 0.85, 2.0, item.h * 0.85);
            } else if (item.type === 'room') {
              const rw = item.rw * bld.w;
              ctx.fillRect(ix, bld.y - item.rh * 0.75, rw, item.rh * 0.75);
            }
          });

          if (bld.depthLayer >= 1) {
            this.staticBldNodes.push({
              type: 'BLD',
              id: bld.id,
              x: bld.x,
              y: bld.y,
              w: bld.w,
              h: Math.min(bld.h * 0.5, 120),
              score: Math.round(bld.h)
            });
          }
        }

        drawCrane(ctx, crane, state, elapsedTime) {
          const lineColor = crane.cachedColor || '#102428';
          const weightColor = '#102428';
          const motionActive = state.animation.playing && state.animation.craneMotion && state.cranes.motion;
          const slewFactor = motionActive
            ? 0.74 + 0.26 * Math.sin(elapsedTime * 0.32 * state.animation.speed + crane.phase)
            : 1.0;
          const trolleyRatio = motionActive
            ? crane.trolleyBase + 0.18 * Math.sin(elapsedTime * 0.48 * state.animation.speed + crane.phase * 1.5)
            : crane.trolleyBase;
          const cableLen = motionActive
            ? crane.cableBaseLength + 12 * Math.cos(elapsedTime * 0.6 * state.animation.speed + crane.phase)
            : crane.cableBaseLength;

          const mx = crane.baseX;
          const mw = crane.mastWidth * (crane.depthLayer === 0 ? 0.95 : 1.22);
          const topY = crane.topY;
          const botY = crane.baseY;
          const jibEndX = mx + crane.dir * crane.jibLength * slewFactor;
          const counterEndX = mx - crane.dir * crane.counterJibLength * slewFactor;
          const apexY = topY - crane.apexHeight * 0.95;
          const trolleyX = mx + crane.dir * crane.jibLength * slewFactor * trolleyRatio;

          ctx.save();
          ctx.strokeStyle = lineColor;
          ctx.fillStyle = lineColor;

          ctx.lineWidth = crane.depthLayer === 0 ? 3.0 : 4.2;
          ctx.beginPath();
          ctx.moveTo(mx - mw * 0.5, botY);
          ctx.lineTo(mx - mw * 0.5, topY);
          ctx.moveTo(mx + mw * 0.5, botY);
          ctx.lineTo(mx + mw * 0.5, topY);
          ctx.stroke();

          ctx.lineWidth = crane.depthLayer === 0 ? 1.8 : 2.5;
          const rungStep = 16;
          for (let y = topY; y < botY - rungStep; y += rungStep) {
            ctx.beginPath();
            ctx.moveTo(mx - mw * 0.5, y);
            ctx.lineTo(mx + mw * 0.5, y);
            ctx.moveTo(mx - mw * 0.5, y);
            ctx.lineTo(mx + mw * 0.5, y + rungStep);
            ctx.stroke();
          }

          ctx.fillStyle = weightColor;
          ctx.fillRect(mx - mw * 0.85, topY - 3, mw * 1.7, 9);

          const jibTrussH = crane.depthLayer === 0 ? 8 : 11;
          ctx.lineWidth = crane.depthLayer === 0 ? 3.4 : 4.8;
          ctx.beginPath();
          ctx.moveTo(counterEndX, topY);
          ctx.lineTo(jibEndX, topY);
          ctx.stroke();

          ctx.lineWidth = crane.depthLayer === 0 ? 2.0 : 2.8;
          ctx.beginPath();
          ctx.moveTo(counterEndX, topY - jibTrussH);
          ctx.lineTo(mx, topY - jibTrussH);
          ctx.lineTo(jibEndX, topY - 2);
          ctx.stroke();

          ctx.lineWidth = crane.depthLayer === 0 ? 2.8 : 3.8;
          ctx.beginPath();
          ctx.moveTo(mx - mw * 0.45, topY - jibTrussH);
          ctx.lineTo(mx, apexY);
          ctx.lineTo(mx + mw * 0.45, topY - jibTrussH);
          ctx.stroke();

          ctx.lineWidth = crane.depthLayer === 0 ? 1.8 : 2.4;
          ctx.beginPath();
          ctx.moveTo(mx, apexY);
          ctx.lineTo(jibEndX - crane.dir * 12, topY - 3);
          ctx.moveTo(mx, apexY);
          ctx.lineTo(counterEndX + crane.dir * 6, topY - jibTrussH);
          ctx.stroke();

          // Stacked Geometric Counterweights on Counter-Jib Tail
          ctx.fillStyle = weightColor;
          const slabW = crane.depthLayer === 0 ? 6 : 8;
          const slabGap = 3;
          for (let k = 0; k < 3; k++) {
            const offset = k * (slabW + slabGap);
            const sx = crane.dir > 0 ? counterEndX + 4 + offset : counterEndX - 4 - slabW - offset;
            const sh = (crane.depthLayer === 0 ? 18 : 24) - k * 3;
            ctx.fillRect(sx, topY - jibTrussH - 3, slabW, sh);
          }

          ctx.fillRect(trolleyX - 7, topY - 2, 14, 6);
          ctx.lineWidth = crane.depthLayer === 0 ? 1.6 : 2.2;
          ctx.beginPath();
          ctx.moveTo(trolleyX - 3, topY + 4);
          ctx.lineTo(trolleyX - 3, topY + 4 + cableLen);
          ctx.moveTo(trolleyX + 3, topY + 4);
          ctx.lineTo(trolleyX + 3, topY + 4 + cableLen);
          ctx.stroke();

          const loadY = topY + 4 + cableLen;
          ctx.fillRect(trolleyX - 6, loadY, 12, 5);
          ctx.fillRect(trolleyX - 13, loadY + 8, 26, 4);
          ctx.fillRect(trolleyX - 12, loadY + 12, 9, 11);
          ctx.fillRect(trolleyX + 3, loadY + 12, 9, 11);
          ctx.restore();

          this.detectedNodes.push({
            type: 'CRN',
            id: crane.id,
            x: Math.min(mx, jibEndX),
            y: apexY,
            w: Math.abs(jibEndX - counterEndX),
            h: crane.apexHeight + 24,
            score: Math.round(crane.jibLength)
          });
        }

        drawBridge(ctx, bridge, state) {
          const bridgeColor = this.resolveColor(state.colors.buildings, -2, -16, state, bridge.depthLayer, 3);
          const th = bridge.thickness;
          const lut = bridge.lut;

          ctx.save();
          ctx.fillStyle = bridgeColor;
          ctx.strokeStyle = bridgeColor;

          bridge.columns.forEach(col => {
            const cw = Math.max(6, col.width * 0.65);
            ctx.fillRect(col.x - cw * 0.5, col.topY - 2, cw, col.bottomY - col.topY + 2);
          });

          ctx.lineWidth = th * 0.75;
          ctx.lineCap = 'butt';
          ctx.beginPath();
          lut.forEach((pt, idx) => {
            if (idx === 0) ctx.moveTo(pt.x, pt.y);
            else ctx.lineTo(pt.x, pt.y);
          });
          ctx.stroke();
          ctx.restore();
        }

        drawVehicle(ctx, v, state) {
          const bridge = this.sceneData.bridges[v.bridgeIndex];
          if (!bridge) return;
          if (v.t < -0.04 || v.t > 1.04) return;

          const sample = BridgeGenerator.sampleBridge(bridge, v.t);
          const scale = state.traffic.size * (bridge.depthLayer === 2 ? 1.0 : (bridge.depthLayer === 0 ? 0.72 : 0.88));
          const w = v.length * scale * 0.85;
          const h = v.height * scale * 0.68;
          const deckTopOffset = -bridge.thickness * 0.37 + v.laneOffset * bridge.thickness * 0.18;

          ctx.save();
          ctx.translate(sample.x, sample.y + deckTopOffset);
          ctx.rotate(sample.angle);
          ctx.fillStyle = v.cachedBlockColor || '#102428';
          ctx.fillRect(-w * 0.5, -h, w, h);
          ctx.restore();

          if (this.detectedNodes.length < 48) {
            this.detectedNodes.push({
              type: 'VEH',
              id: v.id,
              x: sample.x - w * 0.5,
              y: sample.y + deckTopOffset - h,
              w,
              h,
              score: Math.round(v.baseSpeed * 1000)
            });
          }
        }

        drawBillboard(ctx, bb, state, elapsedTime) {
          const structColor = bb.cachedStructColor || '#102428';
          const basePlaneColor = bb.cachedPlaneColor || '#e07a38';
          const pulsePlaneColor = bb.cachedPulseColor || basePlaneColor;
          const ledActive = state.animation.playing && state.animation.billboardMotion && state.billboards.ledAnim;

          ctx.save();
          ctx.strokeStyle = structColor;
          ctx.lineWidth = 1.8;
          const cx = bb.x + bb.w * 0.5;
          ctx.beginPath();
          if (bb.mountType === 'rooftop') {
            ctx.moveTo(bb.x + bb.w * 0.25, bb.y + bb.h);
            ctx.lineTo(bb.x + bb.w * 0.25, bb.supportBottomY);
            ctx.moveTo(bb.x + bb.w * 0.75, bb.y + bb.h);
            ctx.lineTo(bb.x + bb.w * 0.75, bb.supportBottomY);
          } else {
            ctx.moveTo(cx, bb.y + bb.h);
            ctx.lineTo(cx, bb.supportBottomY);
          }
          ctx.stroke();

          const pulse = ledActive ? 0.5 + 0.5 * Math.sin(elapsedTime * 1.6 * state.animation.speed + bb.phaseOffset) : 0;
          ctx.fillStyle = ledActive ? ColorUtils.mixHex(basePlaneColor, pulsePlaneColor, pulse * 0.45) : basePlaneColor;
          ctx.fillRect(bb.x, bb.y, bb.w, bb.h);
          ctx.restore();

          this.detectedNodes.push({
            type: 'BBD',
            id: bb.id,
            x: bb.x,
            y: bb.y,
            w: bb.w,
            h: bb.h,
            score: Math.round(bb.w * bb.h * 0.1)
          });
        }

        drawDataVisualization(ctx, state, elapsedTime) {
          const dv = state.dataviz;
          if (!dv.enable || dv.detection <= 0) return;

          const maxNodes = Math.max(2, Math.floor((dv.detection / 100) * this.detectedNodes.length));
          const activeNodes = this.detectedNodes.slice(0, maxNodes);
          if (!activeNodes.length) return;

          ctx.save();

          if (dv.lines && activeNodes.length > 1) {
            ctx.strokeStyle = dv.linesColor;
            ctx.lineWidth = 1.1;
            const curveFactor = (dv.curvature / 100) * 65;

            let hubNode = activeNodes[0];
            if (dv.connection === 'Hub (Largest)') {
              hubNode = activeNodes.reduce((best, n) => (n.w * n.h > best.w * best.h ? n : best), activeNodes[0]);
            }

            activeNodes.forEach((n, idx) => {
              let target = null;
              if (dv.connection === 'Sequential') {
                target = activeNodes[(idx + 1) % activeNodes.length];
              } else if (dv.connection === 'Hub (Largest)') {
                if (n !== hubNode) target = hubNode;
              } else {
                let bestDist = Infinity;
                activeNodes.forEach((other, oIdx) => {
                  if (oIdx === idx) return;
                  const dx = (other.x + other.w * 0.5) - (n.x + n.w * 0.5);
                  const dy = (other.y + other.h * 0.5) - (n.y + n.h * 0.5);
                  const d2 = dx * dx + dy * dy;
                  if (d2 < bestDist) {
                    bestDist = d2;
                    target = other;
                  }
                });
              }

              if (target) {
                const x1 = n.x + n.w * 0.5, y1 = n.y + n.h * 0.5;
                const x2 = target.x + target.w * 0.5, y2 = target.y + target.h * 0.5;
                ctx.beginPath();
                ctx.moveTo(x1, y1);
                if (dv.lineStyle === 'Curved') {
                  const mx = (x1 + x2) * 0.5;
                  const my = (y1 + y2) * 0.5 - curveFactor;
                  ctx.quadraticCurveTo(mx, my, x2, y2);
                } else {
                  ctx.lineTo(x2, y2);
                }
                ctx.stroke();
              }
            });
          }

          activeNodes.forEach((n, idx) => {
            if (dv.fill) {
              ctx.fillStyle = ColorUtils.rgba(dv.fillColor, dv.fillOpacity / 100);
              ctx.fillRect(n.x, n.y, n.w, n.h);
            }
            if (dv.outline) {
              ctx.strokeStyle = dv.outlineColor;
              ctx.lineWidth = dv.outlineWeight;
              ctx.strokeRect(n.x, n.y, n.w, n.h);
            }
            if (dv.text) {
              ctx.fillStyle = dv.textColor;
              ctx.font = `600 ${dv.textSize}px "JetBrains Mono", monospace`;
              const pulseTag = state.animation.playing ? Math.round(n.x + Math.sin(elapsedTime + idx) * 2) : Math.round(n.x);
              ctx.fillText(`${n.id} [${pulseTag}:${Math.round(n.y)}]`, n.x + 2, n.y - 3);
            }
          });

          ctx.restore();
        }
      }
