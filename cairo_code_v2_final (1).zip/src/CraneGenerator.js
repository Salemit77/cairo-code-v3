// 7. SYSTEM 5: CRANE GENERATOR (Layer 4)
      // -------------------------------------------------------------------
      class CraneGenerator {
        static generate(state, buildings, width, height) {
          if (!state.cranes.enabled) return [];
          const rng = new SeededRNG(state.seed ^ (state.salts.cranes * 2749));
          const count = state.cranes.count;
          const mastH = state.cranes.height * 1.65;
          const jibLen = state.cranes.armLength * 1.35;
          const posMode = state.cranes.position;

          const cranes = [];
          const sortedBlds = buildings.slice().sort((a, b) => a.y - b.y);

          for (let i = 0; i < count; i++) {
            let depthLayer = 1;
            if (posMode === 'background') depthLayer = 0;
            else if (posMode === 'midground') depthLayer = 1;
            else depthLayer = (i % 2 === 0) ? 0 : 1;

            let baseX = ((i + 0.5) / count) * (width * 0.82) + width * 0.09 + rng.range(-35, 35);
            let baseY = height * rng.range(0.45, 0.72);

            if (sortedBlds.length > i) {
              const host = sortedBlds[(i * 2) % sortedBlds.length];
              baseX = host.x + host.w * rng.range(0.25, 0.75);
              baseY = host.y + 20;
            }

            const topY = Math.max(36, baseY - mastH * rng.range(0.85, 1.15));
            const dir = rng.chance(0.5) ? 1 : -1;

            cranes.push({
              id: `CRN_${i}`,
              depthLayer,
              baseX,
              baseY,
              topY,
              mastWidth: rng.range(10, 14),
              jibLength: jibLen * rng.range(0.88, 1.12),
              counterJibLength: jibLen * 0.36,
              apexHeight: rng.range(22, 32),
              dir,
              phase: rng.range(0, Math.PI * 2),
              trolleyBase: rng.range(0.35, 0.82),
              cableBaseLength: rng.range(28, 64)
            });
          }

          return cranes;
        }
      }

      // -------------------------------------------------------------------
