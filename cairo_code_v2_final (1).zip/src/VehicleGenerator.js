// 5. SYSTEM 3: VEHICLE GENERATOR (Layer 6 — Animated Cairo Traffic)
      // -------------------------------------------------------------------
      class VehicleGenerator {
        static generate(state, bridges) {
          if (!state.traffic.enabled || !bridges.length) return [];
          const rng = new SeededRNG(state.seed ^ (state.salts.traffic * 4999));
          const densityPerBridge = state.traffic.density;
          const mix = state.traffic.mix;
          const dirSetting = state.traffic.direction;

          // Vehicle type probability tables
          const mixPools = {
            cairoMix: ['microbus', 'microbus', 'taxi', 'taxi', 'car', 'car', 'car', 'bus', 'truck'],
            microbusHeavy: ['microbus', 'microbus', 'microbus', 'taxi', 'taxi', 'car'],
            carsOnly: ['car', 'car', 'car', 'taxi'],
            publicTransit: ['bus', 'bus', 'microbus', 'microbus', 'microbus', 'taxi'],
            commercial: ['truck', 'truck', 'microbus', 'car', 'bus']
          };
          const pool = mixPools[mix] || mixPools.cairoMix;

          const vehicles = [];

          bridges.forEach((bridge, bIdx) => {
            // Two lanes per bridge (Lane 0: Eastbound L->R, Lane 1: Westbound R->L)
            const lanes = dirSetting === 'both' ? [1, -1] : (dirSetting === 'east' ? [1] : [-1]);
            const vehiclesPerLane = Math.max(1, Math.round(densityPerBridge / lanes.length));

            lanes.forEach((dir, laneIdx) => {
              for (let v = 0; v < vehiclesPerLane; v++) {
                const vType = rng.pick(pool);
                // Evenly space vehicles along [0, 1) with controlled organic jitter so cars never overlap
                const slotSize = 1 / vehiclesPerLane;
                const baseT = (v * slotSize + rng.range(0.12, 0.82) * slotSize) % 1;

                // Speed multiplier per vehicle type (realistic relative speeds)
                let baseSpeed = 0.075;
                if (vType === 'bus') baseSpeed = 0.058;
                else if (vType === 'truck') baseSpeed = 0.062;
                else if (vType === 'microbus') baseSpeed = 0.082;
                else if (vType === 'taxi') baseSpeed = 0.086;
                else baseSpeed = 0.080;

                const speedVar = baseSpeed * rng.range(0.92, 1.08);

                // Dimensions (in base units before vehicleSize scaling)
                let length = 24, height = 10;
                if (vType === 'microbus') { length = 27; height = 13; }
                else if (vType === 'taxi') { length = 23; height = 9.5; }
                else if (vType === 'bus') { length = 42; height = 16; }
                else if (vType === 'truck') { length = 31; height = 14.5; }

                vehicles.push({
                  id: `VEH_${bIdx}_${laneIdx}_${v}`,
                  bridgeIndex: bIdx,
                  depthLayer: bridge.depthLayer,
                  type: vType,
                  dir,
                  laneOffset: laneIdx === 0 ? -0.22 : 0.12,
                  t: baseT,
                  baseSpeed: speedVar,
                  length,
                  height,
                  stripeColor: rng.pick(['#2563eb', '#dc2626', '#16a34a', '#d97706', '#9333ea']),
                  bodyTint: rng.range(-12, 12)
                });
              }
            });
          });

          return vehicles;
        }

        static update(vehicles, dt, state) {
          if (!state.animation.playing || !state.animation.trafficMotion || !state.traffic.enabled) return;
          const speedMult = state.animation.speed * state.traffic.speed;
          for (let i = 0; i < vehicles.length; i++) {
            const v = vehicles[i];
            v.t += v.dir * v.baseSpeed * speedMult * dt;
            if (v.t > 1.06) v.t -= 1.12;
            if (v.t < -0.06) v.t += 1.12;
          }
        }
      }

      // -------------------------------------------------------------------
