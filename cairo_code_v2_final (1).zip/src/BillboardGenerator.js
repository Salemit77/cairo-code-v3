// 6. SYSTEM 4: BILLBOARD GENERATOR (Layer 7)
      // -------------------------------------------------------------------
      class BillboardGenerator {
        static generate(state, buildings, bridges, width, height) {
          if (!state.billboards.enabled) return [];
          const rng = new SeededRNG(state.seed ^ (state.salts.billboards * 3571));
          const count = state.billboards.count;
          const scale = state.billboards.size;
          const placement = state.billboards.placement;
          const gfxMode = state.billboards.graphics;

          const billboards = [];
          const candidateBuildings = buildings.filter(b => b.depthLayer >= 1 && b.w >= 58);

          const cairoSlogans = [
            state.billboards.text || 'CAIRO CODE',
            '6TH OF OCTOBER',
            'NILE TOWERS',
            'RING ROAD EXP',
            'AL AHLY // CAIRO',
            'NEW CAPITAL',
            'METRO LINE 4'
          ];

          for (let i = 0; i < count; i++) {
            let mountType = placement;
            if (placement === 'mixed') {
              mountType = ['rooftop', 'highway', 'led'][i % 3];
            }

            const w = rng.range(68, 115) * scale;
            const h = rng.range(34, 56) * scale;
            let x = rng.range(80, width - 160);
            let y = rng.range(height * 0.25, height * 0.65);
            let supportBottomY = y + h + 45;
            let depthLayer = 2;

            if (mountType === 'rooftop' && candidateBuildings.length > 0) {
              const host = candidateBuildings[i % candidateBuildings.length];
              x = host.x + host.w * 0.5 - w * 0.5 + rng.range(-10, 10);
              supportBottomY = host.y;
              y = host.y - h - rng.range(14, 28);
              depthLayer = host.depthLayer;
            } else if (mountType === 'highway' && bridges.length > 0) {
              const hostBridge = bridges[i % bridges.length];
              const bt = 0.14 + ((i * 0.23 + rng.range(0, 0.08)) % 0.72);
              const pt = BridgeGenerator.sampleBridge(hostBridge, bt);
              x = pt.x - w * 0.5;
              supportBottomY = pt.y;
              y = pt.y - h - rng.range(26, 52);
              depthLayer = hostBridge.depthLayer;
            } else {
              // Tall roadside monopole or LED mega-screen
              x = ((i + 0.5) / count) * (width - 140) + 30 + rng.range(-25, 25);
              y = height * rng.range(0.32, 0.58);
              supportBottomY = height;
              depthLayer = 2;
            }

            let pattern = gfxMode;
            if (gfxMode === 'mixed') {
              pattern = ['geometric', 'typography', 'ledMatrix'][i % 3];
            }

            billboards.push({
              id: `BBD_${i}`,
              mountType,
              depthLayer,
              x,
              y,
              w,
              h,
              supportBottomY,
              pattern,
              phaseOffset: rng.range(0, Math.PI * 2),
              labelIndex: i,
              subSlogan: cairoSlogans[i % cairoSlogans.length]
            });
          }

          return billboards;
        }
      }

      // -------------------------------------------------------------------
